import React, { useState, useContext , useEffect } from "react";
import { Button, Form, Card, Container, Alert } from "react-bootstrap";
import { FormContext } from "./FormContext";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom"; // For react-router v6

const StudentFormWithoutClassInfo = ({ 
  academicYear: propAcademicYear, 
  classLevel: propClassLevel, 
  classDiv: propClassDiv, 
  onBack,
  // Add this if using react-router v5, or use useLocation in v6
}) => {
  const [registid, setregistid] = useState("");
  const [sarlid, setsarlid] = useState("");
  const [adhar, setadhar] = useState("");
  const [mobile, setmobile] = useState("");
  const [rollno, setRollno] = useState("");
  const [errorRollno, setErrorRollno] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [fatherName, setfatherName] = useState("");
  const [error, setError] = useState("");


  const { saveInformationData } = useContext(FormContext);
  const navigate = useNavigate();
  const udiseNo = localStorage.getItem("udise");

  const location = useLocation(); // For react-router v6
  const state = location.state || {};
  
  // Initialize state with priority: location state > props > localStorage
  const [academicYear, setAcademicYear] = useState(
    state.academicYear || propAcademicYear || ''
  );
  const [classLevel, setClassLevel] = useState(
    state.classLevel || propClassLevel || ''
  );
  const [classDiv, setClassDiv] = useState(
    state.classDiv || propClassDiv || ''
  );

  // Save to localStorage whenever values change
  useEffect(() => {
    if (academicYear && classLevel && classDiv) {
      localStorage.setItem('studentClassInfo', JSON.stringify({
        academicYear,
        classLevel,
        classDiv
      }));
    }
  }, [academicYear, classLevel, classDiv]);

  // Load from localStorage on mount if no other values are set
  useEffect(() => {
    if (!academicYear || !classLevel || !classDiv) {
      const savedClassInfo = localStorage.getItem('studentClassInfo');
      if (savedClassInfo) {
        const { academicYear, classLevel, classDiv } = JSON.parse(savedClassInfo);
        setAcademicYear(academicYear);
        setClassLevel(classLevel);
        setClassDiv(classDiv);
      }
    }
  }, []);

  const handelview = () => {
    navigate("/studentInfo/StudentTable", { state: { udiseNo } });
  };

  const handleNext = async () => {
    setError("");
    setErrorRollno("");
    setSuccessMessage("");

    if (!rollno) {
      setError("हजेरी क्रमांक टाइप करा");
      return;
    }
    if (!mobile || mobile.length !== 10) {
      setError("मोबाइल क्रमांक 10 अंकांचा असणे आवश्यक आहे.");
      return;
    }
    if (!adhar || adhar.length !== 12) {
      setError("आधार क्रमांक 12 अंकांचा असणे आवश्यक आहे.");
      return;
    }
    if (!sarlid) {
      setError("सरल आयडी क्रमांक 8 - 50 अंकांच्या दरम्यान असणे आवश्यक आहे.");
      return;
    }
    if (!registid) {
      setError("रजिस्टर क्रमांक 5 - 10 अंकांच्या दरम्यान असणे आवश्यक आहे.");
      return;
    }

    const classdiv = `${classLevel}&&${classDiv}&&${academicYear}`;
    const infoData = {
      academicYear,
      classLevel,
      classDiv,
      rollno,
      registid,
      sarlid,
      adhar,
      mobile,
      classdiv,
      fatherName,
    };

    try {
      localStorage.setItem("informationData", JSON.stringify(infoData));
      saveInformationData(infoData);
      navigate("/studentInfo/step2", { state: { udiseNo } });
    } catch (error) {
      setError("Error saving data: " + error.message);
    }
  };

  const handleChange = (e) => {
    let value = e.target.value;
    if (/^[0-9]*$/.test(value)) {
      if (value.length > 3) {
        value = value.slice(0, 3);
      }
      setRollno(value);
      setErrorRollno("");
    } else {
      setErrorRollno("Please enter only numeric values.");
    }
  };

return (
  <div className="student-form-container" style={{
    background: "linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%)",
    minHeight: "100vh",
    padding: "2rem 0",
    fontFamily: "'Inter', sans-serif"
  }}>
    <div className="container" style={{ maxWidth: "800px" }}>
      {/* Header Section */}
      <div className="text-center mb-5">
        <div style={{
          width: "80px",
          height: "80px",
          background: "linear-gradient(45deg, #3f51b5, #2196f3)",
          borderRadius: "50%",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          marginBottom: "1.5rem",
          boxShadow: "0 4px 20px rgba(33, 150, 243, 0.3)"
        }}>
          <i className="fas fa-user-graduate text-white" style={{ fontSize: "2rem" }}></i>
        </div>
        <h2 style={{
          fontWeight: "700",
          color: "#2c3e50",
          marginBottom: "0.5rem",
          position: "relative",
          display: "inline-block"
        }}>
          STUDENT INFORMATION
          <span style={{
            position: "absolute",
            bottom: "-10px",
            left: "0",
            width: "100%",
            height: "4px",
            background: "linear-gradient(to right, #3f51b5, #2196f3)",
            borderRadius: "2px"
          }}></span>
        </h2>
        <p className="text-muted" style={{ fontWeight: "500" }}>
          STEP-1 (Class: {classLevel} - {classDiv}, Year: {academicYear})
        </p>
      </div>

      {/* Main Form Card */}
      <div style={{
        background: "white",
        borderRadius: "12px",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.08)",
        padding: "2rem",
        marginBottom: "2rem",
        borderLeft: "5px solid #3f51b5"
      }}>
        {/* Alerts */}
        {error && (
          <div className="alert alert-danger d-flex align-items-center" style={{
            borderRadius: "8px",
            borderLeft: "4px solid #e53935",
            marginBottom: "1.5rem"
          }}>
            <i className="fas fa-exclamation-circle me-2"></i>
            {error}
          </div>
        )}
        
        {successMessage && (
          <div className="alert alert-success d-flex align-items-center" style={{
            borderRadius: "8px",
            borderLeft: "4px solid #43a047",
            marginBottom: "1.5rem"
          }}>
            <i className="fas fa-check-circle me-2"></i>
            {successMessage}
          </div>
        )}

        {/* Class Info Card */}
        <div className="d-flex align-items-center mb-4 p-3" style={{
          background: "rgba(63, 81, 181, 0.05)",
          borderRadius: "8px",
          borderLeft: "3px solid #3f51b5"
        }}>
          <div style={{
            width: "40px",
            height: "40px",
            background: "rgba(63, 81, 181, 0.1)",
            borderRadius: "8px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            marginRight: "1rem",
            color: "#3f51b5"
          }}>
            <i className="fas fa-info-circle"></i>
          </div>
          <div>
            <h6 style={{ color: "#3f51b5", marginBottom: "0.25rem", fontWeight: "600" }}>
              Selected Class Information
            </h6>
            <p style={{ marginBottom: "0", fontWeight: "500" }}>
              {classLevel} - {classDiv} ({academicYear})
            </p>
          </div>
        </div>

        {/* Form Fields - 2 Column Layout */}
        <div className="row">
          {/* Column 1 */}
          <div className="col-md-6">
            {/* Roll Number */}
            <div className="mb-4">
              <label className="form-label" style={{ fontWeight: "600", color: "#495057" }}>
                <i className="fas fa-hashtag me-2 text-primary"></i>
                हजेरी क्रमांक
              </label>
              <div className="input-group">
                <span className="input-group-text" style={{ background: "#f8f9fa" }}>
                  <i className="fas fa-sort-numeric-up text-muted"></i>
                </span>
                <input
                  type="number"
                  className={`form-control ${error && (!rollno) ? "is-invalid" : ""}`}
                  value={rollno}
                  onChange={handleChange}
                  placeholder="हजेरी क्रमांक टाइप करा"
                />
                {error && (!rollno) && (
                  <div className="invalid-feedback d-flex align-items-center">
                    <i className="fas fa-exclamation-circle me-2"></i>
                    हजरी क्रमांक आवश्यक आहे
                  </div>
                )}
              </div>
            </div>

            {/* Register ID */}
            <div className="mb-4">
              <label className="form-label" style={{ fontWeight: "600", color: "#495057" }}>
                <i className="fas fa-id-card me-2 text-primary"></i>
                रजिस्टर क्रमांक
              </label>
              <div className="input-group">
                <span className="input-group-text" style={{ background: "#f8f9fa" }}>
                  <i className="fas fa-list-ol text-muted"></i>
                </span>
                <input
                  type="number"
                  className={`form-control ${error && (!registid ) ? "is-invalid" : ""}`}
                  value={registid}
                  onChange={(e) => {
                    const input = e.target.value;
                    if (/^\d{0,10}$/.test(input)) {
                      setregistid(input);
                    }
                  }}
                  placeholder="रजिस्टर क्रमांक टाइप करा"
                />
                {error && (!registid) && (
                  <div className="invalid-feedback d-flex align-items-center">
                    <i className="fas fa-exclamation-circle me-2"></i>
                    नोंदणी क्रमांक आवश्यक आहे.
                  </div>
                )}
              </div>
            </div>

            {/* Aadhar Number */}
            <div className="mb-4">
              <label className="form-label" style={{ fontWeight: "600", color: "#495057" }}>
                <i className="fas fa-fingerprint me-2 text-primary"></i>
                आधार क्रमांक
              </label>
              <div className="input-group">
                <span className="input-group-text" style={{ background: "#f8f9fa" }}>
                  <i className="fas fa-id-card-alt text-muted"></i>
                </span>
                <input
                  type="number"
                  className={`form-control ${error && (!adhar || adhar.length !== 12) ? "is-invalid" : ""}`}
                  value={adhar}
                  onChange={(e) => {
                    const input = e.target.value;
                    if (/^\d{0,12}$/.test(input)) {
                      setadhar(input);
                    }
                  }}
                  placeholder="आधार क्रमांक टाइप करा"
                />
                {error && (!adhar || adhar.length !== 12) && (
                  <div className="invalid-feedback d-flex align-items-center">
                    <i className="fas fa-exclamation-circle me-2"></i>
                    आधार क्रमांक 12 अंकांचा असणे आवश्यक आहे.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Column 2 */}
          <div className="col-md-6">
            {/* Simple ID */}
            <div className="mb-4">
              <label className="form-label" style={{ fontWeight: "600", color: "#495057" }}>
                <i className="fas fa-id-badge me-2 text-primary"></i>
                सरल आयडी क्रमांक
              </label>
              <div className="input-group">
                <span className="input-group-text" style={{ background: "#f8f9fa" }}>
                  <i className="fas fa-qrcode text-muted"></i>
                </span>
                <input
                  type="number"
                  className={`form-control ${error ? "is-invalid" : ""}`}
                  value={sarlid}
                  onChange={(e) => {
                    const input = e.target.value;
                    if (/^\d{0,50}$/.test(input)) {
                      setsarlid(input);
                    }
                  }}
                  placeholder="सरल आयडी क्रमांक टाइप करा"
                />
                {error && (
                  <div className="invalid-feedback d-flex align-items-center">
                    <i className="fas fa-exclamation-circle me-2"></i>
                    सरल आयडी आवश्यक आहे.
                  </div>
                )}
              </div>
            </div>

            {/* Mobile Number */}
            <div className="mb-4">
              <label className="form-label" style={{ fontWeight: "600", color: "#495057" }}>
                <i className="fas fa-mobile-alt me-2 text-primary"></i>
                मोबाइल क्रमांक
              </label>
              <div className="input-group">
                <span className="input-group-text" style={{ background: "#f8f9fa" }}>
                  <i className="fas fa-phone text-muted"></i>
                </span>
                <input
                  type="number"
                  className={`form-control ${error && (!mobile || mobile.length !== 10) ? "is-invalid" : ""}`}
                  value={mobile}
                  onChange={(e) => {
                    const input = e.target.value;
                    if (/^\d{0,10}$/.test(input)) {
                      setmobile(input);
                    }
                  }}
                  placeholder="मोबाइल क्रमांक टाइप करा"
                />
                {error && (!mobile || mobile.length !== 10) && (
                  <div className="invalid-feedback d-flex align-items-center">
                    <i className="fas fa-exclamation-circle me-2"></i>
                    मोबाइल क्रमांक 10 अंकांचा असणे आवश्यक आहे.
                  </div>
                )}
              </div>
            </div>

            {/* Father's Name */}
            <div className="mb-4">
              <label className="form-label" style={{ fontWeight: "600", color: "#495057" }}>
                <i className="fas fa-user-friends me-2 text-primary"></i>
                पालकाचे नाव
              </label>
              <div className="input-group">
                <span className="input-group-text" style={{ background: "#f8f9fa" }}>
                  <i className="fas fa-user text-muted"></i>
                </span>
                <input
                  type="text"
                  className="form-control"
                  value={fatherName}
                  onChange={(e) => setfatherName(e.target.value)}
                  placeholder="पालकाचे नाव टाइप करा"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="d-flex flex-wrap justify-content-center gap-3 mt-5">
          <button 
            onClick={handleNext}
            className="btn btn-primary px-4 py-2 d-flex align-items-center"
            style={{
              borderRadius: "50px",
              fontWeight: "600",
              background: "linear-gradient(to right, #3f51b5, #2196f3)",
              border: "none",
              minWidth: "120px",
              boxShadow: "0 4px 15px rgba(33, 150, 243, 0.3)"
            }}
          >
            <i className="fas fa-arrow-right me-2"></i>
            Next
          </button>
          
          <button 
            onClick={handelview}
            className="btn btn-info px-4 py-2 d-flex align-items-center text-white"
            style={{
              borderRadius: "50px",
              fontWeight: "600",
              background: "linear-gradient(to right, #00bcd4, #0097a7)",
              border: "none",
              minWidth: "120px",
              boxShadow: "0 4px 15px rgba(0, 188, 212, 0.3)"
            }}
          >
            <i className="fas fa-eye me-2"></i>
            View Data
          </button>
          
          <button 
            onClick={() => {
              if (onBack) {
                onBack();
              } else {
                navigate("/studentInfo/studentdashboard", {
                  state: { udiseNo, academicYear, classLevel, classDiv }
                });
              }
            }}
            className="btn btn-secondary px-4 py-2 d-flex align-items-center"
            style={{
              borderRadius: "50px",
              fontWeight: "600",
              background: "linear-gradient(to right, #757575, #616161)",
              border: "none",
              minWidth: "120px",
              boxShadow: "0 4px 15px rgba(117, 117, 117, 0.3)"
            }}
          >
            <i className="fas fa-arrow-left me-2"></i>
            Dashboard
          </button>
        </div>
      </div>
    </div>

    {/* Add this CSS for better form styling */}
    <style>
      {`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        
        body {
          font-family: 'Inter', sans-serif;
        }
        
        .form-control {
          padding: 0.75rem 1rem;
          border-radius: 0 8px 8px 0;
          border-left: none;
        }
        
        .form-control:focus {
          box-shadow: 0 0 0 0.25rem rgba(63, 81, 181, 0.25);
          border-color: #ced4da;
        }
        
        .input-group-text {
          border-radius: 8px 0 0 8px;
          border-right: none;
        }
        
        .btn {
          transition: all 0.3s ease;
        }
        
        .btn:hover {
          transform: translateY(-2px);
        }
      `}
    </style>
  </div>
);


};

export default StudentFormWithoutClassInfo;