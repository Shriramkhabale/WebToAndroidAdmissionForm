import React, { useState, useContext, useEffect } from "react";
import { Button, Form, Card, Container, Alert } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import {ref, get, set , database } from "./firebaseConfig"; // Import your Firebase config
import { useNavigate, useLocation } from "react-router-dom";
import { FormContext } from "./FormContext";
import CreatableSelect from "react-select/creatable";
import "./index.css";

const Step1 = () => {
  const [academicYear, setAcademicYear] = useState("");
  const [classLevel, setClassLevel] = useState("");
  const [division, setDivision] = useState("");
  const [registid, setregistid] = useState("");
  const [sarlid, setsarlid] = useState("");
  const [adhar, setadhar] = useState("");
  const [mobile, setmobile] = useState("");
  // const [error, setError] = useState("");
  const [rollno, setRollno] = useState(""); // State for roll number
  const [errorRollno, setErrorRollno] = useState(""); // State for roll number errors
  const [successMessage, setSuccessMessage] = useState("");
  const [fatherName, setfatherName] = useState("");
  // const [motherName, setmotherName] = useState("");

  const { saveInformationData } = useContext(FormContext);
  const navigate = useNavigate();
  const location = useLocation();

  // Access udiseNo from the location state
  // const  udiseNo  = location.state ;
  const udiseNo = localStorage.getItem("udise");
  console.log("udiseNo");

  const [classDiv, setClassDiv] = useState("");
  const [error, setError] = useState(false);

  // Options for the dropdown
  const classDivOptions = [
    { value: "-", label: "-" },
    { value: "अ", label: "अ" },
    { value: "ब", label: "ब" },
    { value: "क", label: "क" },
    { value: "ड", label: "ड" },
    { value: "इ", label: "इ" },
    { value: "फ", label: "फ" },

    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
    { value: "F", label: "F" },
  ];

  const handleClassDivChange = (selectedOption) => {
    setClassDiv(selectedOption ? selectedOption.value : "");
  };
  // UseEffect to load previously saved form data from localStorage
  useEffect(() => {
    const savedData = JSON.parse(localStorage.getItem("informationData"));
    if (savedData) {
      setAcademicYear(savedData.academicYear || "");
      setClassLevel(savedData.classLevel || "");
      setDivision(savedData.division || "");
      setRollno(savedData.rollno || "");
      setregistid(savedData.registid || "");
      setsarlid(savedData.sarlid || "");
      setadhar(savedData.adhar || "");
      setmobile(savedData.mobile || "");
      setfatherName(savedData.fatherName || "");
    }

    // Clear form data on refresh
    const clearDataOnUnload = () => {
      localStorage.removeItem("informationData");
      setAcademicYear("");
      setClassLevel("");
      setDivision("");
      setRollno("");
      setregistid("");
      setsarlid("");
      setadhar("");
      setmobile("");
      setError("");
      setErrorRollno("");
      setSuccessMessage("");
      setClassDiv("");
      setfatherName("");
    };

    window.addEventListener("beforeunload", clearDataOnUnload);

    // Cleanup on component unmount or before refresh
    return () => {
      window.removeEventListener("beforeunload", clearDataOnUnload);
    };


    
  }, []);

  

  const handelview = () => {
    navigate("/studentInfo/StudentTable", { state: { udiseNo } });
  };
  const handleNext = async () => {
    setError(""); // Clear previous general errors
    setErrorRollno(""); // Clear roll number errors
    setSuccessMessage(""); // Clear success messages

    //  Validation 
    if (!rollno || rollno.length < 1 || rollno.length > 3) {
      setError("हजेरी क्रमांक टाइप करा");
      return;
    }
    if (!mobile || mobile.length !== 10) {
      setError("मोबाइल क्रमांक 10 अंकांचा असणे आवश्यक आहे."); // General error message
      return;
    }
    if (!adhar || adhar.length !== 12) {
      setError("आधार क्रमांक 12 अंकांचा असणे आवश्यक आहे."); // General error message
      return;
    }
    if (!sarlid || sarlid.length < 8 || sarlid.length > 50) {
      setError("सरल आयडी क्रमांक 8 - 50 अंकांच्या दरम्यान असणे आवश्यक आहे.");
      return;
    }
    if (!registid || registid.length < 5 || registid.length > 10) {
      setError("रजिस्टर क्रमांक 5 - 10 अंकांच्या दरम्यान असणे आवश्यक आहे.");
      return;
    }
    // Validate required fields
    if (!classLevel || !academicYear || !classDiv) {
      setError(" कृपया सर्व फील्ड भरा."); // General error message  ""Please fill all required fields""
      return; // Stop execution if other fields are missing
    }
    const classdiv = `${classLevel}&&${classDiv}&&${academicYear}`;
    const basePath = `Abhishek/${classdiv}`; // Parent node path in Firebase


    try {
      // Fetch existing children for the classdiv node
      const classRef = ref(database, basePath);
      const snapshot = await get(classRef);

      let nextId = 1; // Default to 1 if no children exist
      if (snapshot.exists()) {
        nextId = Object.keys(snapshot.val()).length + 1; // Calculate next sequential ID
      }

      console.log("Class Division:", classDiv);
      console.log("father name:", fatherName); // Debugging line

      const infoData = {
        academicYear,
        classLevel,
        classDiv, // Ensure this is included
        rollno,
        registid,
        sarlid,
        adhar,
        mobile,
        classdiv,
        fatherName,
      };

      // Save form data to localStorage
      localStorage.setItem("informationData", JSON.stringify(infoData));

      saveInformationData(infoData);
      navigate("/studentInfo/step2", { state: { udiseNo } });
    } catch (error) {
      setError("Error saving data: " + error.message);
    }
  };
  const academicYears = [];
  const toMarathiNumerals = (num) => {
    const marathiDigits = ["०", "१", "२", "३", "४", "५", "६", "७", "८", "९"];
    return num
      .toString()
      .split("")
      .map((digit) => marathiDigits[parseInt(digit)])
      .join("");
  };

  for (let year = 2020; year < 2030; year++) {
    const startYear = toMarathiNumerals(year);
    const endYear = toMarathiNumerals((year + 1) % 100); // Last two digits of next year
    academicYears.push(`${startYear}-${endYear}`);
  }

  const classLevelsOptions = [
    { value: "इयत्ता पहिली", label: "इयत्ता पहिली" },
    { value: "इयत्ता दुसरी", label: "इयत्ता दुसरी" },
    { value: "इयत्ता तिसरी", label: "इयत्ता तिसरी" },
    { value: "इयत्ता चौथी", label: "इयत्ता चौथी" },
    { value: "इयत्ता पाचवी", label: "इयत्ता पाचवी" },
    { value: "इयत्ता सहावी", label: "इयत्ता सहावी" },
    { value: "इयत्ता सातवी", label: "इयत्ता सातवी" },
    { value: "इयत्ता आठवी", label: "इयत्ता आठवी" },
    { value: "इयत्ता नववी", label: "इयत्ता नववी" },
    { value: "इयत्ता दहावी", label: "इयत्ता दहावी" },
    { value: "इयत्ता अकरावी-कला(Arts)", label: "इयत्ता अकरावी-कला(Arts)" },
    {
      value: "इयत्ता अकरावी-वाणिज्य (Commerce)",
      label: "इयत्ता अकरावी-वाणिज्य (Commerce)",
    },
    {
      value: "इयत्ता अकरावी-विज्ञान(Science)",
      label: "इयत्ता अकरावी-विज्ञान(Science)",
    },
    { value: "इयत्ता बारावी-कला(Arts)", label: "इयत्ता बारावी-कला(Arts)" },
    {
      value: "इयत्ता बारावी-वाणिज्य(Commerce)",
      label: "इयत्ता बारावी-वाणिज्य(Commerce)",
    },
    {
      value: "इयत्ता बारावी-विज्ञान(Science)",
      label: "इयत्ता बारावी-विज्ञान(Science)",
    },
  ];

  // Function to handle input changes
  const handleChange = (e) => {
    let value = e.target.value;

    if (/^[0-9]*$/.test(value)) {
      if (value.length > 3) {
        value = value.slice(0, 3); // Trim to 3 digits
      }
      setRollno(value);
      setErrorRollno(""); // Clear any error message on valid input
    } else {
      setErrorRollno("Please enter only numeric values.");
    }
  };

  return (
    <Container
      fluid
      className="d-flex justify-content-center align-items-center mb"
      style={{ background: "#D7DAE5" }}
    >
      <Card
        className="p-4 col-12 col-md-8 col-lg-6 "
        style={{
          borderRadius: "15px",
          backgroundColor: "#E3F3F1  ",
          margin: "15px",
        }}
      >
        <h4
          className="text-center "
          style={{
            fontWeight: "bold",
            color: "#343a40",
            fontFamily: "popover",
            letterSpacing: "1.5px",
          }}
        >
          STUDENT INFORMATION
        </h4>
        <h6
          className="text-center mt-2 pb-2"
          style={{
            fontWeight: "bold",
            color: "#343a40",
            fontFamily: "popover",
            letterSpacing: "0.7px",
          }}
        >
          STEP-1
        </h6>

        <Form>
          {/* Error message */}
          {error && (
            <Alert variant="danger" className="text-center">
              {error}
            </Alert>
          )}
          {/* Success message */}
          {successMessage && (
            <Alert variant="success" className="text-center">
              {successMessage}
            </Alert>
          )}

          {/* Academic Year */}

          <Form.Group controlId="academicYear" className=" mb-3">
            <Form.Label
              className="fw-semibold text-secondary"
              style={{ fontFamily: "Annapurna SIL", fontSize: "18px" }}
            >
              शैक्षणिक वर्ष :
            </Form.Label>
            <Form.Select
              value={academicYear}
              onChange={(e) => setAcademicYear(e.target.value)}
              // className="shadow-sm"
              // style={{ fontSize: '16px', padding: '10px' }}
              isInvalid={!academicYear && error}
            >
              <option>शैक्षणिक वर्ष निवडा</option>
              {academicYears.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </Form.Select>
            <Form.Control.Feedback type="invalid">
              {/* Please select an academic year. */}
              कृपया शैक्षणिक वर्ष निवडा.
            </Form.Control.Feedback>
          </Form.Group>

          {/* Class Level */}

          <Form.Group controlId="classLevel" className="mb-4">
            <Form.Label
              className="fw-semibold text-secondary"
              style={{ fontFamily: "Annapurna SIL", fontSize: "18px" }}
            >
              वर्ग :
            </Form.Label>
            <CreatableSelect
              value={
                classLevel ? { value: classLevel, label: classLevel } : null
              }
              onChange={(selectedOption) =>
                setClassLevel(selectedOption ? selectedOption.value : "")
              }
              options={classLevelsOptions}
              placeholder="वर्ग निवडा किंवा तयार करा"
              className={`shadow-sm ${
                error && !classLevel ? "is-invalid" : ""
              }`}
              style={{ fontSize: "16px", padding: "10px" }}
            />
            {error && !classLevel && (
              <div className="invalid-feedback">
                {/* Please select or create a वर्ग. */}
                कृपया वर्ग निवडा किंवा तयार करा.
              </div>
            )}
          </Form.Group>

          {/* Division */}

          

          <Form.Group controlId="classDiv" className="mb-4">
            <Form.Label
              className="fw-semibold text-secondary"
              style={{ fontFamily: "Annapurna SIL", fontSize: "18px" }}
            >
              तुकडी :
            </Form.Label>
            <CreatableSelect
              value={classDiv ? { value: classDiv, label: classDiv } : null}
              onChange={handleClassDivChange}
              options={classDivOptions}
              placeholder="तुकडी निवडा किंवा तयार करा"
              className={`shadow-sm ${error && !classDiv ? "is-invalid" : ""}`}
              style={{ fontSize: "16px", padding: "10px" }}
            />
            {error && !classDiv && (
              <div className="invalid-feedback">
                कृपया तुकडी निवडा किंवा तयार करा
              </div>
            )}
          </Form.Group>

          {/* Roll Number */}
 

          <Form.Group controlId="rollno" className="mb-4">
            <Form.Label
              className="fw-semibold text-secondary"
              style={{ fontFamily: "Annapurna SIL", fontSize: "18px" }}
            >
              हजेरी क्रमांक :
            </Form.Label>
            <Form.Control
              type="number"
              value={rollno}
              onChange={handleChange}
              placeholder="हजेरी क्रमांक टाइप करा"
              className={
                error && (!rollno || rollno.toString().length !== 10)
                  ? "is-invalid"
                  : ""
              }
              onBlur={() => {
                if (!rollno || rollno.length < 1 || rollno.length > 3) {
                  setError("हजेरी क्रमांक आवश्यक आहे");
                } else {
                  setError("");
                }
              }}
            />
            {error &&
              (!rollno || rollno.length < 1 || rollno.length > 3) && (
                <div className="invalid-feedback">
                  {/* रजिस्टर क्रमांक must be between 5 digits. */}
                  हजरी क्रमांक आवश्यक आहे
                </div>
              )}
          </Form.Group>

          <Form.Group controlId="registid" className="mb-4">
            <Form.Label
              className="fw-semibold text-secondary"
              style={{ fontFamily: "Annapurna SIL", fontSize: "18px" }}
            >
              रजिस्टर क्रमांक :
            </Form.Label>
            <Form.Control
              type="number"
              value={registid}
              onChange={(e) => {
                const input = e.target.value;
                if (/^\d{0,10}$/.test(input)) {
                  // Allow only up to 10 digits
                  setregistid(input);
                }
              }}
              onBlur={() => {
                if (!registid || registid.length < 5 || registid.length > 10) {
                  setError("रजिस्टर क्रमांक must be between 5 - 10 digits.");
                } else {
                  setError("");
                }
              }}
              placeholder="रजिस्टर क्रमांक टाइप करा"
              className={
                error &&
                (!registid || registid.length < 5 || registid.length > 10)
                  ? "is-invalid"
                  : ""
              }
            />
            {error &&
              (!registid || registid.length < 5 || registid.length > 10) && (
                <div className="invalid-feedback">
                  {/* रजिस्टर क्रमांक must be between 5 digits. */}
                  नोंदणी क्रमांक 5 अंकांच्या दरम्यान असणे आवश्यक आहे.
                </div>
              )}
          </Form.Group>

          {/* SRL ID */}

          <Form.Group controlId="srlid" className="mb-4">
            <Form.Label
              className="fw-semibold text-secondary"
              style={{ fontFamily: "Annapurna SIL", fontSize: "18px" }}
            >
              सरल आयडी क्रमांक :
            </Form.Label>
            <Form.Control
              type="number"
              value={sarlid}
              onChange={(e) => {
                const input = e.target.value;
                // Allow only digits and enforce a maximum length of 50
                if (/^\d{0,50}$/.test(input)) {
                  setsarlid(input);
                }
              }}
              onBlur={() => {
                // Check if the length is between 8 and 50
                if (!sarlid || sarlid.length < 8 || sarlid.length > 50) {
                  setError("सरल आयडी क्रमांक must be between 8 - 50 digits.");
                } else {
                  setError("");
                }
              }}
              placeholder="सरल आयडी क्रमांक टाइप करा"
              className={
                error && (sarlid.length < 8 || sarlid.length > 50)
                  ? "is-invalid"
                  : ""
              }
            />
            {error && (sarlid.length < 8 || sarlid.length > 50) && (
              <div className="invalid-feedback">
                {/* सरल आयडी क्रमांक must be between 8 digits. */}
                सरल आयडी क्रमांक 8 अंकांच्या दरम्यान असणे आवश्यक आहे.
              </div>
            )}
          </Form.Group>

          {/* Aadhaar */}

          <Form.Group controlId="adhar" className="mb-4">
            <Form.Label
              className="fw-semibold text-secondary"
              style={{ fontFamily: "Annapurna SIL", fontSize: "18px" }}
            >
              आधार क्रमांक :
            </Form.Label>
            <Form.Control
              required
              type="number"
              value={adhar}
              onChange={(e) => {
                const input = e.target.value;

                // Allow only up to 12 numeric digits
                if (/^\d{0,12}$/.test(input)) {
                  setadhar(input);
                }
              }}
              onBlur={() => {
                if (!adhar || adhar.length !== 12) {
                  setError("आधार क्रमांक must be exactly 12 digits.");
                } else {
                  setError("");
                }
              }}
              placeholder="आधार क्रमांक टाइप करा"
              className={
                error && (!adhar || adhar.length !== 12) ? "is-invalid" : ""
              }
            />
            {error && (!adhar || adhar.length !== 12) && (
              <div className="invalid-feedback">
                आधार क्रमांक 12 अंकांचा असणे आवश्यक आहे.
              </div>
            )}
          </Form.Group>

          {/* Mobile */}

          <Form.Group controlId="mobile" className="mb-4">
            <Form.Label
              className="fw-semibold text-secondary"
              style={{ fontFamily: "Annapurna SIL", fontSize: "18px" }}
            >
              मोबाइल क्रमांक :
            </Form.Label>
            <Form.Control
              type="number"
              value={mobile}
              onChange={(e) => {
                const input = e.target.value;

                // Allow only numeric input and limit to 10 digits
                if (/^\d{0,10}$/.test(input)) {
                  setmobile(input);
                }
              }}
              onBlur={() => {
                if (!mobile || mobile.length !== 10) {
                  setError("मोबाइल क्रमांक must be exactly 10 digits.");
                } else {
                  setError("");
                }
              }}
              placeholder="मोबाइल क्रमांक टाइप करा"
              className={
                error && (!mobile || mobile.length !== 10) ? "is-invalid" : ""
              }
            />
            {error && (!mobile || mobile.length !== 10) && (
              <div className="invalid-feedback">
                मोबाइल क्रमांक 10 अंकांचा असणे आवश्यक आहे.
              </div>
            )}
          </Form.Group>

          <div className="ms-2 text-center">
            <Button variant="primary" onClick={handleNext}>
              Next
            </Button>
            <Button variant="primary ms-2 " onClick={handelview}>
              ViewData
            </Button>
          </div>
          {/* <button className="text-center button-64 " role="button"><span class="text">Next</span></button>  */}
        </Form>
      </Card>
    </Container>
  );
};

export default Step1;