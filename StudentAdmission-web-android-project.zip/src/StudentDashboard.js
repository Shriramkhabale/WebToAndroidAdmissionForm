
import React, { useState } from "react";
import { Button, Form, Card, Container, Row, Col, Alert } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import CreatableSelect from "react-select/creatable";
import StudentFormWithoutClassInfo from "./StudentFormWithoutClassInfo";
import { useNavigate } from "react-router-dom";

const StudentDashboard = () => {
  // State for form fields
  const [academicYear, setAcademicYear] = useState("");
  const [classLevel, setClassLevel] = useState("");
  const [classDiv, setClassDiv] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  // Options for dropdowns
  const academicYears = [];
  const toMarathiNumerals = (num) => {
    const marathiDigits = ["०", "१", "२", "३", "४", "५", "६", "७", "८", "९"];
    return num
      .toString()
      .split("")
      .map((digit) => marathiDigits[parseInt(digit)])
      .join("");
  };

  for (let year = 2020; year < 2030; year++) {
    const startYear = toMarathiNumerals(year);
    const endYear = toMarathiNumerals((year + 1) % 100);
    academicYears.push(`${startYear}-${endYear}`);
  }

  const classLevelsOptions = [
    { value: "इयत्ता पहिली", label: "इयत्ता पहिली" },
    { value: "इयत्ता दुसरी", label: "इयत्ता दुसरी" },
    { value: "इयत्ता तिसरी", label: "इयत्ता तिसरी" },
    { value: "इयत्ता चौथी", label: "इयत्ता चौथी" },
    { value: "इयत्ता पाचवी", label: "इयत्ता पाचवी" },
    { value: "इयत्ता सहावी", label: "इयत्ता सहावी" },
    { value: "इयत्ता सातवी", label: "इयत्ता सातवी" },
    { value: "इयत्ता आठवी", label: "इयत्ता आठवी" },
    { value: "इयत्ता नववी", label: "इयत्ता नववी" },
    { value: "इयत्ता दहावी", label: "इयत्ता दहावी" },
    { value: "इयत्ता अकरावी-कला(Arts)", label: "इयत्ता अकरावी-कला(Arts)" },
    {
      value: "इयत्ता अकरावी-वाणिज्य (Commerce)",
      label: "इयत्ता अकरावी-वाणिज्य (Commerce)",
    },
    {
      value: "इयत्ता अकरावी-विज्ञान(Science)",
      label: "इयत्ता अकरावी-विज्ञान(Science)",
    },
    { value: "इयत्ता बारावी-कला(Arts)", label: "इयत्ता बारावी-कला(Arts)" },
    {
      value: "इयत्ता बारावी-वाणिज्य(Commerce)",
      label: "इयत्ता बारावी-वाणिज्य(Commerce)",
    },
    {
      value: "इयत्ता बारावी-विज्ञान(Science)",
      label: "इयत्ता बारावी-विज्ञान(Science)",
    },
  ];

  const classDivOptions = [
    { value: "-", label: "-" },
    { value: "अ", label: "अ" },
    { value: "ब", label: "ब" },
    { value: "क", label: "क" },
    { value: "ड", label: "ड" },
    { value: "इ", label: "इ" },
    { value: "फ", label: "फ" },
    { value: "A", label: "A" },
    { value: "B", label: "B" },
    { value: "C", label: "C" },
    { value: "D", label: "D" },
    { value: "E", label: "E" },
    { value: "F", label: "F" },
  ];

  const handleClassDivChange = (selectedOption) => {
    setClassDiv(selectedOption ? selectedOption.value : "");
  };

  const handleExcelClick = () => {
    const udiseNo = localStorage.getItem("udise");
    if (!udiseNo) {
      alert("UDISE number not found. Please login again.");
      return;
    }
    navigate("/studentInfo/StudentTable/", { state: { udiseNo } });
  };

  const handleFormClick = () => {
    if (!academicYear || !classLevel || !classDiv) {
      setError("कृपया शैक्षणिक वर्ष, वर्ग आणि तुकडी निवडा");
      return;
    }
    setError("");
    setShowForm(true);
  };

  const handleBackToDashboard = () => {
    setShowForm(false);
  };

  if (showForm) {
    return (
      <StudentFormWithoutClassInfo 
        academicYear={academicYear}
        classLevel={classLevel}
        classDiv={classDiv}
        onBack={handleBackToDashboard}
      />
    );
  }

 

return (
  <Container fluid className="px-4 py-5" style={{ 
    background: "radial-gradient(circle at 10% 20%, rgba(248, 249, 250, 0.9) 0%, rgba(233, 236, 239, 0.9) 90%)",
    minHeight: "100vh"
  }}>
    {/* Glassmorphism Header Card */}
    <Card className="p-4 mb-5 glass-card" style={{ 
      borderRadius: "18px",
      border: "none",
      backdropFilter: "blur(12px)",
      backgroundColor: "rgba(255, 255, 255, 0.75)",
      boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.1)"
    }}>
      <div className="text-center mb-4">
        <h4 className="mb-0 gradient-text" style={{ 
          fontWeight: "800", 
          letterSpacing: "1.5px",
          textTransform: "uppercase",
          fontSize: "1.75rem",
          background: "linear-gradient(90deg, #4e73df 0%, #224abe 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent"
        }}>
          <i className="fas fa-user-graduate me-3" style={{ 
            background: "linear-gradient(135deg, #4e73df 0%, #224abe 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent"
          }}></i>
          STUDENT DASHBOARD
        </h4>
        <div className="divider-line" style={{
          height: "3px",
          width: "120px",
          background: "linear-gradient(90deg, #4e73df 0%, #224abe 100%)",
          margin: "12px auto",
          borderRadius: "3px"
        }}></div>
      </div>

      {error && (
        <Alert variant="danger" className="text-center rounded-pill glass-card" style={{
          border: "none",
          backdropFilter: "blur(12px)",
          backgroundColor: "rgba(220, 53, 69, 0.15)"
        }}>
          <i className="fas fa-exclamation-circle me-2"></i>
          {error}
        </Alert>
      )}

      <Form>
    

        <Row className="g-3">
 

  <Col md={4}>
    <Form.Group controlId="classLevel" className="position-relative" style={{ zIndex: 1000 }}>
      <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
        <i className="fas fa-layer-group me-2" style={{ color: "#4e73df" }}></i>
        वर्ग
      </Form.Label>
      <CreatableSelect
        value={classLevel ? { value: classLevel, label: classLevel } : null}
        onChange={(selectedOption) => setClassLevel(selectedOption ? selectedOption.value : "")}
        options={classLevelsOptions}
        placeholder="वर्ग निवडा किंवा तयार करा"
        className="shadow-sm"
        styles={{
          control: (base) => ({
            ...base,
            borderRadius: "12px",
            border: "1px solid rgba(78, 115, 223, 0.2)",
            backgroundColor: "rgba(255, 255, 255, 0.7)",
            minHeight: "48px",
            boxShadow: "none",
            "&:hover": {
              borderColor: "rgba(78, 115, 223, 0.4)"
            }
          }),
          menu: (base) => ({
            ...base,
            borderRadius: "12px",
            border: "1px solid rgba(78, 115, 223, 0.2)",
            backgroundColor: "rgba(255, 255, 255, 0.98)",
            backdropFilter: "blur(12px)",
            zIndex: 9999,
            marginTop: "4px"
          }),
          menuPortal: base => ({ ...base, zIndex: 9999 })
        }}
        menuPortalTarget={document.body}
        menuPosition="fixed"
      />
    </Form.Group>
  </Col>

  <Col md={4}>
    <Form.Group controlId="classDiv" className="position-relative" style={{ zIndex: 999 }}>
      <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
        <i className="fas fa-users me-2" style={{ color: "#4e73df" }}></i>
        तुकडी
      </Form.Label>
      <CreatableSelect
        value={classDiv ? { value: classDiv, label: classDiv } : null}
        onChange={handleClassDivChange}
        options={classDivOptions}
        placeholder="तुकडी निवडा किंवा तयार करा"
        className="shadow-sm"
        styles={{
          control: (base) => ({
            ...base,
            borderRadius: "12px",
            border: "1px solid rgba(78, 115, 223, 0.2)",
            backgroundColor: "rgba(255, 255, 255, 0.7)",
            minHeight: "48px",
            boxShadow: "none",
            "&:hover": {
              borderColor: "rgba(78, 115, 223, 0.4)"
            }
          }),
          menu: (base) => ({
            ...base,
            borderRadius: "12px",
            border: "1px solid rgba(78, 115, 223, 0.2)",
            backgroundColor: "rgba(255, 255, 255, 0.98)",
            backdropFilter: "blur(12px)",
            zIndex: 9999,
            marginTop: "4px"
          }),
          menuPortal: base => ({ ...base, zIndex: 9999 })
        }}
        menuPortalTarget={document.body}
        menuPosition="fixed"
      />
    </Form.Group>
  </Col>

   <Col md={4}>
    <Form.Group controlId="academicYear" className="position-relative">
      <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
        <i className="fas fa-calendar-alt me-2" style={{ color: "#4e73df" }}></i>
        शैक्षणिक वर्ष
      </Form.Label>
      <Form.Select
        value={academicYear}
        onChange={(e) => setAcademicYear(e.target.value)}
        className="shadow-sm glass-card"
        style={{ 
          borderRadius: "12px",
          border: "1px solid rgba(78, 115, 223, 0.2)",
          backgroundColor: "rgba(255, 255, 255, 0.7)",
          height: "48px"
        }}
      >
        <option>शैक्षणिक वर्ष निवडा</option>
        {academicYears.map((year) => (
          <option key={year} value={year}>{year}</option>
        ))}
      </Form.Select>
    </Form.Group>
  </Col>
</Row>
      </Form>
    </Card>

    {/* Neomorphic Stats Cards */}
    <Row className="g-4">

    <Col md={4}>
      
    </Col>
      <Col md={4}>
        <div className="neumorphic-card h-100" style={{ 
          borderRadius: "18px",
          padding: "1.5rem",
          transition: "all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)",
          position: "relative",
          overflow: "hidden"
        }}>
          <div className="position-absolute top-0 start-0 w-100 h-100" style={{
            background: "linear-gradient(135deg, rgba(28, 200, 138, 0.1) 0%, rgba(28, 200, 138, 0.03) 100%)",
            zIndex: 0
          }}></div>
          <Card.Body className="d-flex flex-column align-items-center justify-content-center p-0 position-relative" style={{ zIndex: 1 }}>
            <div className="icon-circle mb-4" style={{
              background: "linear-gradient(135deg, #1cc88a 0%, #17a673 100%)",
              boxShadow: "0 4px 12px rgba(28, 200, 138, 0.3)"
            }}>
              <i className="fas fa-file-excel text-white"></i>
            </div>
            <Card.Title className="text-center mb-4" style={{ 
              color: "#2e3a4d",
              fontWeight: 700,
              fontSize: "1.25rem"
            }}>Students Details</Card.Title>
            <Button 
              variant="success" 
              className="mb-3 w-100 rounded-pill py-2 border-0"
              onClick={handleExcelClick}
              style={{ 
                fontWeight: 600,
                background: "linear-gradient(135deg, #1cc88a 0%, #17a673 100%)",
                boxShadow: "0 4px 8px rgba(28, 200, 138, 0.2)"
              }}
            >
              <i className="fas fa-download me-2"></i>
              Import/Export Data
            </Button>
            <Button 
              variant="primary" 
              className="w-100 rounded-pill py-2 border-0"
              onClick={handleFormClick}
              style={{ 
                fontWeight: 600,
                background: "linear-gradient(135deg, #4e73df 0%, #224abe 100%)",
                boxShadow: "0 4px 8px rgba(78, 115, 223, 0.2)"
              }}
            >
              <i className="fas fa-plus-circle me-2"></i>
              Enter Students Details
            </Button>
          </Card.Body>
        </div>
      </Col>

    <Col md={4}>
      
    </Col>
      {/* <Col md={4}>
        <div className="neumorphic-card h-100" style={{ 
          borderRadius: "18px",
          padding: "1.5rem",
          transition: "all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)",
          position: "relative",
          overflow: "hidden"
        }}>
          <div className="position-absolute top-0 start-0 w-100 h-100" style={{
            background: "linear-gradient(135deg, rgba(54, 185, 204, 0.1) 0%, rgba(54, 185, 204, 0.03) 100%)",
            zIndex: 0
          }}></div>
          <Card.Body className="p-0 position-relative" style={{ zIndex: 1 }}>
            <div className="text-center mb-4">
              <div className="icon-circle mb-3" style={{
                background: "linear-gradient(135deg, #36b9cc 0%, #2a96a5 100%)",
                boxShadow: "0 4px 12px rgba(54, 185, 204, 0.3)"
              }}>
                <i className="fas fa-chart-pie text-white"></i>
              </div>
              <Card.Title style={{ 
                color: "#2e3a4d",
                fontWeight: 700,
                fontSize: "1.25rem"
              }}>Statistics</Card.Title>
            </div>
            <div className="px-2">
              <div className="d-flex justify-content-between align-items-center mb-3">
                <span className="text-muted small d-flex align-items-center">
                  <i className="fas fa-users me-2" style={{ color: "#4e73df" }}></i>
                  Total Students:
                </span>
                <span className="fw-bold" style={{ color: "#4e73df", fontSize: "1.1rem" }}>120</span>
              </div>
              <div className="progress mb-4" style={{ height: "10px", borderRadius: "5px" }}>
                <div 
                  className="progress-bar" 
                  role="progressbar" 
                  style={{ 
                    width: "100%",
                    background: "linear-gradient(90deg, #4e73df 0%, #224abe 100%)",
                    borderRadius: "5px"
                  }}
                ></div>
              </div>
              
              <div className="d-flex justify-content-between align-items-center mb-3">
                <span className="text-muted small d-flex align-items-center">
                  <i className="fas fa-male me-2" style={{ color: "#36b9cc" }}></i>
                  Boys:
                </span>
                <span className="fw-bold" style={{ color: "#36b9cc", fontSize: "1.1rem" }}>65</span>
              </div>
              <div className="progress mb-4" style={{ height: "10px", borderRadius: "5px" }}>
                <div 
                  className="progress-bar" 
                  role="progressbar" 
                  style={{ 
                    width: "54%",
                    background: "linear-gradient(90deg, #36b9cc 0%, #2a96a5 100%)",
                    borderRadius: "5px"
                  }}
                ></div>
              </div>
              
              <div className="d-flex justify-content-between align-items-center mb-2">
                <span className="text-muted small d-flex align-items-center">
                  <i className="fas fa-female me-2" style={{ color: "#f6c23e" }}></i>
                  Girls:
                </span>
                <span className="fw-bold" style={{ color: "#f6c23e", fontSize: "1.1rem" }}>55</span>
              </div>
              <div className="progress" style={{ height: "10px", borderRadius: "5px" }}>
                <div 
                  className="progress-bar" 
                  role="progressbar" 
                  style={{ 
                    width: "46%",
                    background: "linear-gradient(90deg, #f6c23e 0%, #dda20a 100%)",
                    borderRadius: "5px"
                  }}
                ></div>
              </div>
            </div>
          </Card.Body>
        </div>
      </Col>

      <Col md={4}>
        <div className="neumorphic-card h-100" style={{ 
          borderRadius: "18px",
          padding: "1.5rem",
          transition: "all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)",
          position: "relative",
          overflow: "hidden"
        }}>
          <div className="position-absolute top-0 start-0 w-100 h-100" style={{
            background: "linear-gradient(135deg, rgba(246, 194, 62, 0.1) 0%, rgba(246, 194, 62, 0.03) 100%)",
            zIndex: 0
          }}></div>
          <Card.Body className="p-0 position-relative" style={{ zIndex: 1 }}>
            <div className="text-center mb-4">
              <div className="icon-circle mb-3" style={{
                background: "linear-gradient(135deg, #f6c23e 0%, #dda20a 100%)",
                boxShadow: "0 4px 12px rgba(246, 194, 62, 0.3)"
              }}>
                <i className="fas fa-link text-white"></i>
              </div>
              <Card.Title style={{ 
                color: "#2e3a4d",
                fontWeight: 700,
                fontSize: "1.25rem"
              }}>Quick Links</Card.Title>
            </div>
            <div className="d-grid gap-3">
              <Button 
                variant="outline-primary" 
                className="rounded-pill py-2 text-start d-flex align-items-center"
                style={{ 
                  borderWidth: "2px",
                  borderColor: "#4e73df",
                  color: "#4e73df",
                  fontWeight: 600,
                  background: "rgba(78, 115, 223, 0.1)",
                  transition: "all 0.3s ease"
                }}
                onMouseEnter={(e) => {
                  e.target.style.background = "linear-gradient(90deg, rgba(78, 115, 223, 0.2) 0%, rgba(78, 115, 223, 0.1) 100%)";
                  e.target.style.color = "#fff";
                  e.target.style.borderColor = "transparent";
                }}
                onMouseLeave={(e) => {
                  e.target.style.background = "rgba(78, 115, 223, 0.1)";
                  e.target.style.color = "#4e73df";
                  e.target.style.borderColor = "#4e73df";
                }}
              >
                <i className="fas fa-users me-3"></i>
                View All Students
              </Button>
              <Button 
                variant="outline-secondary" 
                className="rounded-pill py-2 text-start d-flex align-items-center"
                style={{ 
                  borderWidth: "2px",
                  borderColor: "#6c757d",
                  color: "#6c757d",
                  fontWeight: 600,
                  background: "rgba(108, 117, 125, 0.1)",
                  transition: "all 0.3s ease"
                }}
              >
                <i className="fas fa-clipboard-list me-3"></i>
                Attendance Report
              </Button>
              <Button 
                variant="outline-info" 
                className="rounded-pill py-2 text-start d-flex align-items-center"
                style={{ 
                  borderWidth: "2px",
                  borderColor: "#36b9cc",
                  color: "#36b9cc",
                  fontWeight: 600,
                  background: "rgba(54, 185, 204, 0.1)",
                  transition: "all 0.3s ease"
                }}
              >
                <i className="fas fa-chart-line me-3"></i>
                Performance Analysis
              </Button>
            </div>
          </Card.Body>
        </div>
      </Col> */}
    </Row>

    {/* Custom CSS */}
    <style>
      {`
        .glass-card {
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
        }
        
        .neumorphic-card {
          background: rgba(255, 255, 255, 0.75);
          box-shadow: 8px 8px 16px #d1d9e6, -8px -8px 16px #ffffff;
          border: none;
        }
        
        .neumorphic-card:hover {
          transform: translateY(-5px);
          box-shadow: 12px 12px 24px #d1d9e6, -12px -12px 24px #ffffff;
        }
        
        .icon-circle {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 60px;
          height: 60px;
          border-radius: 50%;
          font-size: 1.4rem;
          transition: all 0.3s ease;
        }
        
        .icon-circle:hover {
          transform: scale(1.1) rotate(10deg);
        }
        
        .gradient-text {
          background-clip: text;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        
        .btn-outline-primary:hover {
          background: linear-gradient(90deg, #4e73df 0%, #224abe 100%);
          color: white !important;
        }
        
        .btn-outline-secondary:hover {
          background: linear-gradient(90deg, #6c757d 0%, #495057 100%);
          color: white !important;
        }
        
        .btn-outline-info:hover {
          background: linear-gradient(90deg, #36b9cc 0%, #2a96a5 100%);
          color: white !important;
        }
      `}
    </style>
  </Container>
);

};

export default StudentDashboard;