
import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { FormProvider } from "./FormContext";
// import Step1 from "./Info";
import Step2 from "./Step2";
import StudentTable from "./StudentTable";
import StudentDashboard from "./StudentDashboard";
import StudentFormWithoutClassInfo from "./StudentFormWithoutClassInfo";
import Login from "./Login";

function App() {
  return (
    <FormProvider>
      <Router>
        <Routes>
        <Route path="/studentInfo/" element={<Login />} />
         <Route path="/studentInfo/StudentDashboard/" element={<StudentDashboard />} />
          <Route path="/studentInfo/StudentFormWithoutClassInfo/" element={<StudentFormWithoutClassInfo />} />
          <Route path="/studentInfo/step2/" element={<Step2 />} />
          <Route path="/studentInfo/StudentTable/" element={<StudentTable />} />
        
        </Routes>
      </Router>
    </FormProvider>
  );
}

export default App;
































// import React from 'react';

// import Info1 from './Info1';

// const App = () => {
//   return (
//   <>
//     <Info1/>
    
//   </>
//   );
// };

// export default App;


