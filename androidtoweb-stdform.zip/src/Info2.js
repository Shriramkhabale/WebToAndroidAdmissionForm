import React, { useState } from 'react';
import { Button, Form, Card, Container, Alert } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { database, ref, get, set } from './firebaseConfig'; // Import firebase methods

const Information = () => {
  const [academicYear, setAcademicYear] = useState('');
  const [classLevel, setClassLevel] = useState('');
  const [division, setDivision] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const [attendanceNumber, setAttendanceNumber] = useState('');
  const [registerNumber, setRegisterNumber] = useState('');
  const [simpleId, setSimpleId] = useState('');
  const [aadharNumber, setAadharNumber] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');

  const handleSave = async () => {
    // Reset error and success message
    setError('');
    setSuccessMessage('');

    // Validation for Division (तुकडी): only single character in any language
    const divisionRegex = /^[\p{L}]{1}$/u; // Allows a single Unicode letter
    if (!divisionRegex.test(division)) {
      setError('तुकडी should be a single letter in any language.');
      return;
    }

    // Check if the combination already exists in Firebase
    const path = `Classes/${classLevel}&&${division}&&${academicYear}`;
    const classRef = ref(database, path);

    try {
      const snapshot = await get(classRef);

      if (snapshot.exists()) {
        // If the node exists, show an error message
        setError('This class and division already exist in the database.');
      } else {
        // If the node does not exist, save the new data
        // Saving the form data under the class level, division, and academic year
        await set(classRef, {
          academicYear,
          classLevel,
          division,
          attendanceNumber,
          registerNumber,
          simpleId,
          aadharNumber,
          mobileNumber
        }); // Save the data under the appropriate node

        setSuccessMessage(`Saved successfully for: ${academicYear}, ${classLevel}, ${division}`);

        // For demonstration purposes, alert the saved data
        alert(`Saved: ${academicYear}, ${classLevel}, ${division}`);
      }
    } catch (error) {
      setError('Error checking existing data: ' + error.message);
    }
  };

  // Generate academic years from 1980 to 2050
  const academicYears = [];
  for (let year = 1980; year < 2050; year++) {
    academicYears.push(`${year}-${year + 1}`);
  }

  // Class levels from इयत्ता पहिली to इयत्ता दहावी
  const classLevels = [
    "इयत्ता पहिली",
    "इयत्ता दुसरी",
    "इयत्ता तिसरी",
    "इयत्ता चौथी",
    "इयत्ता पाचवी",
    "इयत्ता सहावी",
    "इयत्ता सातवी",
    "इयत्ता आठवी",
    "इयत्ता नववी",
    "इयत्ता दहावी"
  ];

  return (
    <Container fluid className="d-flex justify-content-center align-items-center my-4">
      <Card className="p-4 col-12 col-md-8 col-lg-6" style={{ borderRadius: '15px', backgroundColor: '#f8f9fa' }}>
        <h4 className="text-center mb-4" style={{ fontWeight: 'bold', color: '#343a40' }}>Class, Division & Academic Year Selection</h4>

        <Form>
          {/* Display error if any */}
          {error && <Alert variant="danger" className="text-center">{error}</Alert>}
          {/* Display success message */}
          {successMessage && <Alert variant="success" className="text-center">{successMessage}</Alert>}

          {/* Academic Year Selection */}
          <Form.Group controlId="academicYear" className="mb-4">
            <Form.Label className="fw-semibold text-secondary">शैक्षणिक वर्ष :</Form.Label>
            <Form.Select
              value={academicYear}
              onChange={(e) => setAcademicYear(e.target.value)}
              className="mt-2 shadow-sm"
              style={{ fontSize: '16px', padding: '10px' }}
            >
              <option value="">Select Academic Year</option>
              {academicYears.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </Form.Select>
          </Form.Group>

          {/* Class Level Dropdown */}
          <Form.Group controlId="classLevel" className="mb-4">
            <Form.Label className="fw-semibold text-secondary">वर्ग :</Form.Label>
            <Form.Select
              value={classLevel}
              onChange={(e) => setClassLevel(e.target.value)}
              className="mt-2 shadow-sm"
              style={{ fontSize: '16px', padding: '10px' }}
            >
              <option value="">Select Class Level</option>
              {classLevels.map((level) => (
                <option key={level} value={level}>
                  {level}
                </option>
              ))}
            </Form.Select>
          </Form.Group>

          {/* Division Input */}
          <Form.Group controlId="division" className="mb-4">
            <Form.Label className="fw-semibold text-secondary">तुकडी :</Form.Label>
            <Form.Control
              type="text"
              value={division}
              onChange={(e) => setDivision(e.target.value)}
              placeholder="Enter a single letter (e.g., ब or A)"
              className="mt-2 shadow-sm"
              style={{ fontSize: '16px', padding: '10px' }}
            />
          </Form.Group>

          {/* Attendance Number */}
          <Form.Group controlId="attendanceNumber" className="mb-4">
            <Form.Label className="fw-semibold text-secondary">हजरी क्रमांक : *</Form.Label>
            <Form.Control
              type="text"
              value={attendanceNumber}
              onChange={(e) => setAttendanceNumber(e.target.value)}
              placeholder="Enter Attendance Number"
              required
              className="mt-2 shadow-sm"
              style={{ fontSize: '16px', padding: '10px' }}
            />
          </Form.Group>

          {/* Register Number */}
          <Form.Group controlId="registerNumber" className="mb-4">
            <Form.Label className="fw-semibold text-secondary">रजिस्टर क्रमांक :</Form.Label>
            <Form.Control
              type="text"
              value={registerNumber}
              onChange={(e) => setRegisterNumber(e.target.value)}
              placeholder="Enter Register Number"
              className="mt-2 shadow-sm"
              style={{ fontSize: '16px', padding: '10px' }}
            />
          </Form.Group>

          {/* Simple ID Number */}
          <Form.Group controlId="simpleId" className="mb-4">
            <Form.Label className="fw-semibold text-secondary">सरल आयडी क्रमांक :</Form.Label>
            <Form.Control
              type="text"
              value={simpleId}
              onChange={(e) => setSimpleId(e.target.value)}
              placeholder="Enter Simple ID"
              className="mt-2 shadow-sm"
              style={{ fontSize: '16px', padding: '10px' }}
            />
          </Form.Group>

          {/* Aadhar Number */}
          <Form.Group controlId="aadharNumber" className="mb-4">
            <Form.Label className="fw-semibold text-secondary">आधार क्रमांक :</Form.Label>
            <Form.Control
              type="text"
              value={aadharNumber}
              onChange={(e) => setAadharNumber(e.target.value)}
              placeholder="Enter Aadhar Number"
              className="mt-2 shadow-sm"
              style={{ fontSize: '16px', padding: '10px' }}
            />
          </Form.Group>

          {/* Mobile Number */}
          <Form.Group controlId="mobileNumber" className="mb-4">
            <Form.Label className="fw-semibold text-secondary">मोबाइल क्रमांक :</Form.Label>
            <Form.Control
              type="text"
              value={mobileNumber}
              onChange={(e) => setMobileNumber(e.target.value)}
              placeholder="Enter Mobile Number"
              className="mt-2 shadow-sm"
              style={{ fontSize: '16px', padding: '10px' }}
            />
          </Form.Group>

          {/* Save Button */}
          <div className="text-center">
            <Button
              variant="primary"
              onClick={handleSave}
              className="px-5 fw-bold"
              style={{
                backgroundColor: '#007bff',
                borderColor: '#007bff',
                padding: '12px 20px',
                fontSize: '18px',
                borderRadius: '30px',
                transition: 'background-color 0.3s ease',
              }}
              onMouseOver={(e) => e.target.style.backgroundColor = '#0056b3'}
              onMouseOut={(e) => e.target.style.backgroundColor = '#007bff'}
            >
              SAVE
            </Button>
          </div>
        </Form>
      </Card>
    </Container>
  );
};

export default Information;