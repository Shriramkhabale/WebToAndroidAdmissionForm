import React, { useState } from "react";
import { Container, Form, Card, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import { ref, get, child } from "firebase/database";
import { database } from "./firebaseConfig";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    // Validate username format
    if (!/^[0-9]{10}$/.test(username)) {
      setError("Username must be exactly 10 digits.");
      toast.error("Username must be exactly 10 digits.");
      return;
    }

    try {
      // Reference to Firebase Realtime Database
      const dbRef = ref(database);

      // Check if the username exists in the database
      const snapshot = await get(child(dbRef, `Users/${username}`));

      if (snapshot.exists()) {
        const userData = snapshot.val();
        console.log("userData", userData.Udise);

        // Check if the password matches (no validation for password format)
        if (userData.Pin === password) {
          const udiseNo = Array.isArray(userData.Udise) ? userData.Udise[0] : userData.Udise;
          console.log(typeof udiseNo, udiseNo);

          // Show success toast
          toast.success("Login Successful!");
localStorage.setItem("udise",udiseNo)
          // Navigate after a short delay to allow the toast to show
          setTimeout(() => {
            navigate("/StudentDashboard", { state: { udiseNo } });
          }, 2000);
        } else {
          // setError("Invalid password.");
          toast.error("Invalid password.");
        }
      } else {
        setError("Username does not exist.");
        toast.error("Username does not exist.");
      }
    } catch (err) {
      console.error("Error accessing Firebase:", err);
      setError("An error occurred. Please try again later.");
      toast.error("An error occurred. Please try again later.");
    }
  };

  return (
    <Container
      fluid
      className="d-flex justify-content-center align-items-center vh-100"
      style={{ background: "#D7DAE5" }}
    >
      <Card
        className="p-4 shadow"
        style={{
          borderRadius: "15px",
          backgroundColor: "#E3F3F1",
          margin: "15px",
          width: "400px",
        }}
      >
        <h2
          className="text-center mb-4"
          style={{
            fontWeight: "bold",
            color: "#343a40",
            letterSpacing: "1.5px",
          }}
        >
          LOGIN
        </h2>

        {error && <div className="alert alert-danger text-center">{error}</div>}

        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3">
            <Form.Label>Username</Form.Label>
            <Form.Control
              type="text"
              value={username}
              style={{ fontFamily: "Annapurna SIL", fontSize: "18px" }}
              onChange={(e) => {
                const value = e.target.value;
                if (/^\d{0,10}$/.test(value)) {
                  setUsername(value);
                }
              }}
              placeholder="Enter 10-digit username"
              maxLength="10"
              required
            />
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Password</Form.Label>
            <Form.Control
              type="password"
              value={password}
              maxLength="4"
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              required
            />
          </Form.Group>

          <Button type="submit" variant="primary" className="w-100">
            Login
          </Button>
        </Form>
      </Card>

      {/* Toast container */}
      <ToastContainer position="top-center" autoClose={3000} />
    </Container>
  );
}

export default Login;







