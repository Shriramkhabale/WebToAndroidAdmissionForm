import React, { createContext, useState } from "react";

export const FormContext = createContext();

export const FormProvider = ({ children }) => {
  const [informationData, setInformationData] = useState({});
  const [step2Data, setStep2Data] = useState({});

  const saveInformationData = (data) => setInformationData(data);
  const saveStep2Data = (data) => setStep2Data(data);

  return (
    <FormContext.Provider value={{ informationData, step2Data, saveInformationData, saveStep2Data }}>
      {children}
    </FormContext.Provider>
  );
};
