import React, { useState, useContext, useEffect } from "react";
import { Container, Form, Button, Col, Row, Card } from "react-bootstrap";
import { useNavigate, useLocation } from "react-router-dom";
import { FormContext } from "./FormContext";
import CreatableSelect from "react-select/creatable";

import { database, ref, set, get } from "./firebaseConfig";

const Step2 = () => {
  const [formData, setFormData] = useState({
    sname: "",
    fatherName: "",
    motherName: "",
    Gender: "",
    DOB: "",
    age: "",
    mtlange: "",
    religion: "",
    caste: "",
    casteCategory: "",
    address: "",
  });

  const { informationData } = useContext(FormContext);
  const navigate = useNavigate();
  // const udiseno=
  const location = useLocation();
  // const [formData, setFormData] = useState({ mtlange: "" });
  const [error, setError] = useState(false); // Error st
  // Access udiseNo from the location state
  // const  {udiseNo}  = location.state || {};
  // const udiseNoArray = location.state?.udiseNo || [];

  const udiseNo = localStorage.getItem("udise");
  // const udiseNo = udiseNoArray.udiseNo

  console.log("udiseNo", udiseNo);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    if (name === "DOB") {
      setFormData((prevData) => ({
        ...prevData,
        age: calculateAge(value),
      }));
    }
  };

  const calculateAge = (DOB) => {
    const birth = new Date(DOB);
    const today = new Date();
    let years = today.getFullYear() - birth.getFullYear();
    let months = today.getMonth() - birth.getMonth();
    let days = today.getDate() - birth.getDate();

    if (days < 0) {
      months -= 1;
      days += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
    }
    if (months < 0) {
      years -= 1;
      months += 12;
    }

    return `${years} वर्ष / ${months} महिने / ${days} दिवस`;
  };

  const handleBack = () => {
    navigate("/step1");
  };




  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Convert the DOB to DD/MM/YYYY format
      const formattedDOB = formatDate(formData.DOB);

      // Combine informationData and formData
      const combinedData = {
        ...informationData,
        ...formData,
        DOB: formattedDOB,
        FMname: `${formData.fatherName}&&${formData.motherName}`,
        fatherName: formData.fatherName,
        motherName: formData.motherName,
        subcaste: `${formData.religion}&&${formData.caste}&&${formData.casteCategory}`,
        religion: formData.religion,
        caste: formData.caste,
        casteCategory: formData.casteCategory,
      };

      const path = `Scinfo/${udiseNo}/ShareStudent/${combinedData.classLevel}&&${combinedData.classDiv}&&${combinedData.academicYear}`;
      const divisionRef = ref(database, path);

      const snapshot = await get(divisionRef);
      const nextId = snapshot.exists() ? snapshot.size + 1 : 1;


      await set(ref(database, `${path}/${nextId}`), combinedData);

      alert("Data saved successfully!");

      // Redirect with all necessary data
      navigate("/StudentFormWithoutClassInfo", {
        state: {
          academicYear: combinedData.academicYear,  // Use the values from combinedData
          classLevel: combinedData.classLevel,
          classDiv: combinedData.classDiv,
          udiseNo: udiseNo
        }
      });

    } catch (error) {
      console.error("Error saving data:", error);
      alert("Failed to save data. Please try again.");
    }
  };

  const formatDate = (date) => {
    const birthDate = new Date(date);
    const day = String(birthDate.getDate()).padStart(2, "0");
    const month = String(birthDate.getMonth() + 1).padStart(2, "0"); // Months are zero-indexed
    const year = birthDate.getFullYear();

    return `${day}/${month}/${year}`;
  };


  return (
    <Container
      fluid
      className="d-flex justify-content-center align-items-center py-5"
      style={{
        background: "linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%)",
        minHeight: "100vh",
        fontFamily: "'Poppins', sans-serif"
      }}
    >
      <Card
        className="p-4 col-12 col-md-10 col-lg-8"
        style={{
          borderRadius: "20px",
          boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
          border: "none",
          background: "linear-gradient(to bottom right, #ffffff, #f8f9fa)"
        }}
      >
        {/* Header Section */}
        <div className="text-center mb-4">
          <div
            className="mx-auto mb-3"
            style={{
              width: "70px",
              height: "70px",
              background: "linear-gradient(45deg, #4e73df, #224abe)",
              borderRadius: "50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 4px 20px rgba(78, 115, 223, 0.3)"
            }}
          >
            <i className="fas fa-user-graduate text-white" style={{ fontSize: "1.8rem" }}></i>
          </div>
          <h4
            className="mb-1"
            style={{
              fontWeight: "700",
              color: "#2e3a4d",
              letterSpacing: "1px",
              position: "relative",
              paddingBottom: "10px"
            }}
          >
            STUDENT INFORMATION
            <span
              style={{
                position: "absolute",
                bottom: "0",
                left: "50%",
                transform: "translateX(-50%)",
                width: "80px",
                height: "4px",
                background: "linear-gradient(to right, #4e73df, #224abe)",
                borderRadius: "2px"
              }}
            ></span>
          </h4>
          <h6
            className="mt-2 text-muted"
            style={{
              fontWeight: "500",
              fontSize: "0.9rem"
            }}
          >
            STEP-2
          </h6>
        </div>

        <Form onSubmit={handleSubmit}>
          {/* Two Column Layout for Form Fields */}
          <Row>
            {/* Left Column */}
            <Col md={6}>
              {/* Student Name */}
              <Form.Group controlId="sname" className="mb-4">
                <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
                  <i className="fas fa-user me-2"></i>
                  विद्यार्थ्याचे संपूर्ण नाव
                </Form.Label>
                <div className="input-group">
                  <span className="input-group-text bg-light">
                    <i className="fas fa-pencil-alt text-muted"></i>
                  </span>
                  <Form.Control
                    type="text"
                    name="sname"
                    placeholder="विद्यार्थ्याचे संपूर्ण नाव टाइप करा"
                    value={formData.sname}
                    onChange={(e) =>
                      /^[A-Za-zअ-हअ-ू़\u0900-\u0961a\s]*$/.test(e.target.value) &&
                      handleChange(e)
                    }
                    className="shadow-sm"
                    required
                  />
                </div>
              </Form.Group>

              {/* Father's Name */}
              <Form.Group controlId="fatherName" className="mb-4">
                <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
                  <i className="fas fa-male me-2"></i>
                  वडिलांचे नाव
                </Form.Label>
                <div className="input-group">
                  <span className="input-group-text bg-light">
                    <i className="fas fa-pencil-alt text-muted"></i>
                  </span>
                  <Form.Control
                    type="text"
                    name="fatherName"
                    placeholder="वडिलांचे नाव टाइप करा"
                    value={formData.fatherName}
                    onChange={(e) =>
                      /^[A-Za-zअ-हअ-ू़\u0900-\u0961a\s]*$/.test(e.target.value) &&
                      handleChange(e)
                    }
                    className="shadow-sm"
                    required
                  />
                </div>
              </Form.Group>

              {/* Mother's Name */}
              <Form.Group controlId="motherName" className="mb-4">
                <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
                  <i className="fas fa-female me-2"></i>
                  आईचे नाव
                </Form.Label>
                <div className="input-group">
                  <span className="input-group-text bg-light">
                    <i className="fas fa-pencil-alt text-muted"></i>
                  </span>
                  <Form.Control
                    type="text"
                    name="motherName"
                    placeholder="आईचे नाव टाइप करा"
                    value={formData.motherName}
                    onChange={(e) =>
                      /^[A-Za-zअ-हअ-ू़\u0900-\u0961a\s]*$/.test(e.target.value) &&
                      handleChange(e)
                    }
                    className="shadow-sm"
                    required
                  />
                </div>
              </Form.Group>

              {/* Gender */}
              <Form.Group controlId="Gender" className="mb-4">
                <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
                  <i className="fas fa-venus-mars me-2"></i>
                  लिंग
                </Form.Label>
                <div className="d-flex gap-3">
                  <Form.Check
                    type="radio"
                    label="मुलगा"
                    name="Gender"
                    value="मुलगा"
                    checked={formData.Gender === "मुलगा"}
                    onChange={handleChange}
                    className="form-check-inline"
                    id="maleRadio"
                  />
                  <Form.Check
                    type="radio"
                    label="मुलगी"
                    name="Gender"
                    value="मुलगी"
                    checked={formData.Gender === "मुलगी"}
                    onChange={handleChange}
                    className="form-check-inline"
                    id="femaleRadio"
                  />
                  <Form.Check
                    type="radio"
                    label="इतर"
                    name="Gender"
                    value="इतर"
                    checked={formData.Gender === "इतर"}
                    onChange={handleChange}
                    className="form-check-inline"
                    id="otherRadio"
                  />
                </div>
              </Form.Group>
            </Col>

            {/* Right Column */}
            <Col md={6}>
              {/* Date of Birth */}
              <Form.Group controlId="DOB" className="mb-4">
                <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
                  <i className="fas fa-calendar-day me-2"></i>
                  जन्म तारीख
                </Form.Label>
                <div className="input-group">
                  <span className="input-group-text bg-light">
                    <i className="fas fa-calendar text-muted"></i>
                  </span>
                  <Form.Control
                    type="date"
                    name="DOB"
                    value={formData.DOB}
                    onChange={handleChange}
                    className="shadow-sm"
                    max={new Date().toISOString().split("T")[0]}
                    required
                  />
                </div>
              </Form.Group>

              {/* Age (read-only) */}
              <Form.Group controlId="age" className="mb-4">
                <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
                  <i className="fas fa-birthday-cake me-2"></i>
                  वय
                </Form.Label>
                <Form.Control
                  type="text"
                  name="age"
                  value={formData.age}
                  readOnly
                  className="shadow-sm bg-light"
                />
              </Form.Group>

              {/* Mother Tongue */}
              <Form.Group controlId="mtlange" className="mb-4">
                <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
                  <i className="fas fa-language me-2"></i>
                  मातृभाषा
                </Form.Label>
                <CreatableSelect
                  value={
                    formData.mtlange
                      ? { value: formData.mtlange, label: formData.mtlange }
                      : null
                  }
                  onChange={(selectedOption) =>
                    setFormData({
                      ...formData,
                      mtlange: selectedOption ? selectedOption.value : "",
                    })
                  }
                  options={[
                    { value: "मराठी", label: "मराठी" },
                    { value: "हिंदी", label: "हिंदी" },
                    { value: "इंग्रजी", label: "इंग्रजी" },
                  ]}
                  placeholder="मातृभाषा निवडा किंवा तयार करा"
                  className={`shadow-sm ${error && !formData.mtlange ? "is-invalid" : ""
                    }`}
                  styles={{
                    control: (base) => ({
                      ...base,
                      minHeight: '44px',
                      borderRadius: '8px',
                      borderColor: error && !formData.mtlange ? '#dc3545' : '#ced4da'
                    })
                  }}
                />
                {error && !formData.mtlange && (
                  <div className="invalid-feedback d-flex align-items-center mt-1">
                    <i className="fas fa-exclamation-circle me-2"></i>
                    कृपया मातृभाषा निवडा किंवा तयार करा
                  </div>
                )}
              </Form.Group>

              {/* Religion */}
              <Form.Group controlId="religion" className="mb-4">
                <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
                  <i className="fas fa-praying-hands me-2"></i>
                  धर्म
                </Form.Label>
                <div className="input-group">
                  <span className="input-group-text bg-light">
                    <i className="fas fa-pencil-alt text-muted"></i>
                  </span>
                  <Form.Control
                    type="text"
                    name="religion"
                    placeholder="धर्म टाइप करा"
                    value={formData.religion}
                    onChange={(e) =>
                      /^[A-Za-zअ-हअ-ू़\u0900-\u0961a\s]*$/.test(e.target.value) &&
                      handleChange(e)
                    }
                    className="shadow-sm"
                    required
                  />
                </div>
              </Form.Group>
            </Col>
          </Row>

          {/* Full Width Fields */}
          <Row>
            <Col md={6}>
              {/* Caste */}
              <Form.Group controlId="caste" className="mb-4">
                <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
                  <i className="fas fa-users me-2"></i>
                  जात
                </Form.Label>
                <div className="input-group">
                  <span className="input-group-text bg-light">
                    <i className="fas fa-pencil-alt text-muted"></i>
                  </span>
                  <Form.Control
                    type="text"
                    name="caste"
                    placeholder="जात टाइप करा"
                    value={formData.caste}
                    onChange={(e) =>
                      /^[A-Za-zअ-हअ-ू़\u0900-\u0961a\s]*$/.test(e.target.value) &&
                      handleChange(e)
                    }
                    className="shadow-sm"
                    required
                  />
                </div>
              </Form.Group>
            </Col>
            <Col md={6}>
              {/* Caste Category */}
              <Form.Group controlId="casteCategory" className="mb-4">
                <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
                  <i className="fas fa-user-tag me-2"></i>
                  जात वर्ग
                </Form.Label>
                <div className="input-group">
                  <span className="input-group-text bg-light">
                    <i className="fas fa-pencil-alt text-muted"></i>
                  </span>
                  <Form.Control
                    type="text"
                    name="casteCategory"
                    value={formData.casteCategory}
                    onChange={(e) =>
                      /^[A-Za-zअ-हअ-ू़\u0900-\u0961a\s]*$/.test(e.target.value) &&
                      handleChange(e)
                    }
                    className="shadow-sm"
                    required
                  />
                </div>
              </Form.Group>
            </Col>
          </Row>

          {/* Address */}
          <Form.Group controlId="address" className="mb-4">
            <Form.Label className="fw-semibold text-muted small mb-2 d-flex align-items-center">
              <i className="fas fa-map-marker-alt me-2"></i>
              संपूर्ण पत्ता
            </Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              name="address"
              placeholder="पत्ता टाइप करा"
              value={formData.address}
              onChange={(e) =>
                /^[A-Za-zअ-हअ-ू़\u0900-\u0961a\s]*$/.test(e.target.value) &&
                handleChange(e)
              }
              className="shadow-sm"
              style={{ resize: "none" }}
              required
            />
          </Form.Group>

          {/* Action Buttons */}
          <div className="d-flex justify-content-between mt-4">
            <Button
              variant="outline-secondary"
              onClick={handleBack}
              className="rounded-pill px-4 py-2 d-flex align-items-center"
              style={{
                fontWeight: "600",
                minWidth: "120px",
                borderWidth: "2px"
              }}
            >
              <i className="fas fa-arrow-left me-2"></i>
              Back
            </Button>
            <Button
              type="submit"
              variant="primary"
              className="rounded-pill px-4 py-2 d-flex align-items-center"
              style={{
                fontWeight: "600",
                minWidth: "120px",
                background: "linear-gradient(to right, #4e73df, #224abe)",
                border: "none",
                boxShadow: "0 4px 15px rgba(78, 115, 223, 0.3)"
              }}
            >
              Submit
              <i className="fas fa-paper-plane ms-2"></i>
            </Button>
          </div>
        </Form>
      </Card>

      {/* Add custom styles */}
      <style>
        {`
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');
        
        body {
          font-family: 'Poppins', sans-serif;
        }
        
        .form-control, .form-select, .react-select__control {
          padding: 0.75rem 1rem;
          border-radius: 8px !important;
        }
        
        .form-control:focus, .form-select:focus {
          box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.25);
          border-color: #bac8f3;
        }
        
        .input-group-text {
          border-radius: 8px 0 0 8px !important;
          background-color: #f8f9fa !important;
        }
        
        .btn {
          transition: all 0.3s ease;
        }
        
        .btn:hover {
          transform: translateY(-2px);
        }
        
        .btn-outline-secondary:hover {
          background-color: #f8f9fa;
        }
      `}
      </style>
    </Container>
  );

};

export default Step2;
