import React, { useState } from 'react';
import { Container, Form, Button, Col, Row, Card } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';

const Info1 = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    studentName: '',
    fatherName: '',
    motherName: '',
    gender: '',
    birthDate: '',
    age: '',
    language: '',
    religion: '',
    caste: '',
    casteCategory: '',
    address: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    if (name === 'birthDate') {
      setFormData((prevData) => ({
        ...prevData,
        age: calculateAge(value),
      }));
    }
  };

  const calculateAge = (birthDate) => {
    const birth = new Date(birthDate);
    const today = new Date();
    let years = today.getFullYear() - birth.getFullYear();
    let months = today.getMonth() - birth.getMonth();
    let days = today.getDate() - birth.getDate();

    if (days < 0) {
      months -= 1;
      days += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
    }
    if (months < 0) {
      years -= 1;
      months += 12;
    }

    return `${years} वर्ष / ${months} महिने / ${days} दिवस`;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
    // Save the form data to localStorage or context
    localStorage.setItem('studentPersonalInfo', JSON.stringify(formData));
    // Navigate to StudentFormWithoutClassInfo
    navigate('/StudentFormWithoutClassInfo'); // Make sure this route is set up in your router
  };

  const handleBack = () => {
    // Navigate back to the previous page
    navigate(-1);
  };

  return (
    <Container className="d-flex justify-content-center align-items-center my-4">
      <Card style={{ width: '100%', maxWidth: '600px' }} className="p-4 shadow-sm">
        <Card.Body>
          <Card.Title className="text-center mb-4">Student Information</Card.Title>
          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="studentName" className="mb-3">
              <Form.Label>विद्यार्थ्याचे संपूर्ण नाव :</Form.Label>
              <Form.Control
                type="text"
                name="studentName"
                placeholder="विद्यार्थ्याचे संपूर्ण नाव टाइप करा"
                value={formData.studentName}
                onChange={(e) => {
                  const value = e.target.value;
                  // Restrict input to alphabetic characters only (including spaces)
                  if (/^[A-Za-z\s]*$/.test(value)) {
                    handleChange(e);
                  }
                }}
                required
               
              />
            </Form.Group>

            <Form.Group controlId="fatherName" className="mb-3">
              <Form.Label>वडिलांचे नाव :</Form.Label>
              <Form.Control
                type="text"
                name="fatherName"
                placeholder="वडिलांचे नाव टाइप करा"
                value={formData.fatherName}
                onChange={(e) => {
                  const value = e.target.value;
                  // Restrict input to alphabetic characters only (including spaces)
                  if (/^[A-Za-z\s]*$/.test(value)) {
                    handleChange(e);
                  }
                }}
                required
              />
            </Form.Group>

            <Form.Group controlId="motherName" className="mb-3">
              <Form.Label>आईचे नाव :</Form.Label>
              <Form.Control
                type="text"
                name="motherName"
                placeholder="आईचे नाव टाइप करा"
                value={formData.motherName}
                onChange={(e) => {
                  const value = e.target.value;
                  // Restrict input to alphabetic characters only (including spaces)
                  if (/^[A-Za-z\s]*$/.test(value)) {
                    handleChange(e);
                  }
                }}
                required
              />
            </Form.Group>

            <Form.Group controlId="gender" className="mb-3">
              <Form.Label>लिंग :</Form.Label>
              <Row>
                <Col>
                  <Form.Check
                    type="radio"
                    label="मुलगा"
                    name="gender"
                    value="मुलगा"
                    checked={formData.gender === 'मुलगा'}
                    onChange={handleChange}
                  />
                </Col>
                <Col>
                  <Form.Check
                    type="radio"
                    label="मुलगी"
                    name="gender"
                    value="मुलगी"
                    checked={formData.gender === 'मुलगी'}
                    onChange={handleChange}
                  />
                </Col>
                <Col>
                  <Form.Check
                    type="radio"
                    label="इतर"
                    name="gender"
                    value="इतर"
                    checked={formData.gender === 'इतर'}
                    onChange={handleChange}
                  />
                </Col>
              </Row>
            </Form.Group>

            <Form.Group controlId="birthDate" className="mb-3">
              <Form.Label>जन्म तारीख :</Form.Label>
              <Form.Control
                type="date"
                name="birthDate"
                value={formData.birthDate}
                onChange={handleChange}
                required
              />
            </Form.Group>

            <Form.Group controlId="age" className="mb-3">
              <Form.Label>वय :</Form.Label>
              <Form.Control
                type="text"
                name="age"
                placeholder=""
                value={formData.age}
                readOnly
              />
            </Form.Group>

            <Form.Group controlId="language" className="mb-3">
              <Form.Label>मातृभाषा :</Form.Label>
              <Form.Select
                name="language"
                value={formData.language}
                onChange={handleChange}
                required
              >
                <option value="">मातृभाषा निवडा</option>
                <option value="Marathi">मराठी</option>
                <option value="Hindi">हिंदी</option>
                <option value="English">इंग्रजी</option>
              </Form.Select>
            </Form.Group>

            <Form.Group controlId="religion" className="mb-3">
              <Form.Label>धर्म :</Form.Label>
              <Form.Control
                type="text"
                name="religion"
                placeholder="धर्म टाइप करा"
                value={formData.religion}
                onChange={handleChange}
              />
            </Form.Group>

            <Form.Group controlId="caste" className="mb-3">
              <Form.Label>जात :</Form.Label>
              <Form.Control
                type="text"
                name="caste"
                placeholder="जात टाइप करा"
                value={formData.caste}
                onChange={handleChange}
              />
            </Form.Group>

            <Form.Group controlId="casteCategory" className="mb-3">
              <Form.Label>जात वर्ग :</Form.Label>
              <Form.Control
                type="text"
                name="casteCategory"
                placeholder=""
                value={formData.casteCategory}
                onChange={handleChange}
              />
            </Form.Group>

            <Form.Group controlId="address" className="mb-3">
              <Form.Label>संपूर्ण पत्ता :</Form.Label>
              <Form.Control
                as="textarea"
                rows={2}
                name="address"
                placeholder="पत्ता टाइप करा"
                value={formData.address}
                onChange={handleChange}
              />
            </Form.Group>

            <Row>
              <Col>
                <Button variant="secondary" onClick={handleBack} className="mt-3 w-100">
                  Back
                </Button>
              </Col>
              <Col>
                  <Button type="submit" variant="primary" className="mt-3 w-100">
                  Submit
                </Button>
              </Col>
            </Row>
          </Form>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default Info1;
