import React, { useEffect, useState } from "react";
import { getDatabase, ref, onValue, remove, set,get, update } from "firebase/database";
import { getStorage, ref as storageRef, getDownloadURL } from "firebase/storage";
import { useLocation } from "react-router-dom";
import * as XLSX from "xlsx";
import { Button, Form, Card, Container, Alert, Row, Col, Modal } from "react-bootstrap";
import "../src/App.css";
import { parse, format } from 'date-fns';


// Define class levels options
const classLevelsOptions = [
  { value: "इयत्ता पहिली", label: "इयत्ता पहिली" },
  { value: "इयत्ता दुसरी", label: "इयत्ता दुसरी" },
  { value: "इयत्ता तिसरी", label: "इयत्ता तिसरी" },
  { value: "इयत्ता चौथी", label: "इयत्ता चौथी" },
  { value: "इयत्ता पाचवी", label: "इयत्ता पाचवी" },
  { value: "इयत्ता सहावी", label: "इयत्ता सहावी" },
  { value: "इयत्ता सातवी", label: "इयत्ता सातवी" },
  { value: "इयत्ता आठवी", label: "इयत्ता आठवी" },
  { value: "इयत्ता नववी", label: "इयत्ता नववी" },
  { value: "इयत्ता दहावी", label: "इयत्ता दहावी" },
  { value: "इयत्ता अकरावी-कला(Arts)", label: "इयत्ता अकरावी-कला(Arts)" },
  { value: "इयत्ता अकरावी-वाणिज्य(Commerce)", label: "इयत्ता अकरावी-वाणिज्य(Commerce)" },
  { value: "इयत्ता अकरावी-विज्ञान(Science)", label: "इयत्ता अकरावी-विज्ञान(Science)" },
  { value: "इयत्ता बारावी-कला(Arts)", label: "इयत्ता बारावी-कला(Arts)" },
  { value: "इयत्ता बारावी-वाणिज्य(Commerce)", label: "इयत्ता बारावी-वाणिज्य(Commerce)" },
  { value: "इयत्ता बारावी-विज्ञान(Science)", label: "इयत्ता बारावी-विज्ञान(Science)" },
];

const classDivOptions = [
  { value: "-", label: "-" },
  { value: "अ", label: "अ" },
  { value: "ब", label: "ब" },
  { value: "क", label: "क" },
  { value: "ड", label: "ड" },
  { value: "इ", label: "इ" },
  { value: "फ", label: "फ" },
];


// Edit Student Form Component
function EditStudentForm({ studentData, udiseNo, selectedClass, onSave, onCancel }) {
  const [formData, setFormData] = useState(studentData);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    // Basic validation
    if (!formData.sname || !formData.rollno || !formData.adhar) {
      setError('Please fill in all required fields');
      return;
    }

    // Prepare the updated data
    const updatedData = {
      ...formData,
      FMname: `${formData.fatherName || ''}&&${formData.motherName || ''}`,
      subcaste: `${formData.religion || ''}&&${formData.caste || ''}&&${formData.casteCategory || ''}`,
      classdiv: `${formData.classLevel || ''}&&${formData.classDiv || ''}&&${formData.academicYear || ''}`
    };

    onSave(updatedData);
  };


  return (
    <Container className="mt-4 px-0">
      <Card className="border-0 shadow-lg rounded-3 overflow-hidden">
        <div className="bg-primary text-white py-3">
          <h3 className="text-center mb-0 fw-light">
            <i className="bi bi-pencil-square me-2"></i>
            Edit Student Profile
          </h3>
        </div>
        
        <Card.Body className="p-4 p-md-5">
          {error && (
            <Alert variant="danger" className="rounded-pill shadow-sm">
              <i className="bi bi-exclamation-triangle-fill me-2"></i>
              {error}
            </Alert>
          )}
          
          {successMessage && (
            <Alert variant="success" className="rounded-pill shadow-sm">
              <i className="bi bi-check-circle-fill me-2"></i>
              {successMessage}
            </Alert>
          )}

          <Form onSubmit={handleSubmit} className="needs-validation" noValidate>
            <div className="row g-4">
              {/* Personal Details Column */}
              <div className="col-md-6">
                <div className="glass-card p-4 h-100 rounded-3">
                  <h5 className="text-primary mb-4 border-bottom pb-2">
                    <i className="bi bi-person-badge me-2"></i>
                    Personal Details
                  </h5>
                  
                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Student Name *</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-person-fill text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="sname"
                        value={formData.sname || ''}
                        onChange={handleChange}
                        required
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Roll Number *</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-123 text-primary"></i>
                      </span>
                      <Form.Control
                        type="number"
                        name="rollno"
                        value={formData.rollno || ''}
                        onChange={handleChange}
                        required
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Aadhaar Number *</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-credit-card-fill text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="adhar"
                        value={formData.adhar || ''}
                        onChange={handleChange}
                        required
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Mobile Number</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-phone-fill text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="mobile"
                        value={formData.mobile || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Date of Birth</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-calendar-date text-primary"></i>
                      </span>
                      <Form.Control
                        type="date"
                        name="DOB"
                        value={formData.DOB || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Age</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-calendar text-primary"></i>
                      </span>
                      <Form.Control
                        type="number"
                        name="age"
                        value={formData.age || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>
                </div>
              </div>

              {/* Family & Academic Details Column */}
              <div className="col-md-6">
                <div className="glass-card p-4 h-100 rounded-3">
                  <h5 className="text-primary mb-4 border-bottom pb-2">
                    <i className="bi bi-people-fill me-2"></i>
                    Family & Academic Info
                  </h5>
                  
                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Father's Name</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-gender-male text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="fatherName"
                        value={formData.fatherName || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Mother's Name</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-gender-female text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="motherName"
                        value={formData.motherName || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Gender</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-gender-ambiguous text-primary"></i>
                      </span>
                      <Form.Select
                        name="Gender"
                        value={formData.Gender || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      >
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                      </Form.Select>
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Class</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-book text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="classLevel"
                        value={formData.classLevel || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Division</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-columns text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="classDiv"
                        value={formData.classDiv || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Academic Year</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-calendar-year text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="academicYear"
                        value={formData.academicYear || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>
                </div>
              </div>

              {/* Additional Information Column */}
              <div className="col-md-6">
                <div className="glass-card p-4 h-100 rounded-3">
                  <h5 className="text-primary mb-4 border-bottom pb-2">
                    <i className="bi bi-info-circle-fill me-2"></i>
                    Additional Information
                  </h5>
                  
                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Religion</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-heart-fill text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="religion"
                        value={formData.religion || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Caste</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-people-fill text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="caste"
                        value={formData.caste || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Caste Category</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-tags-fill text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="casteCategory"
                        value={formData.casteCategory || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Mother Tongue</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-translate text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="mtlange"
                        value={formData.mtlange || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>
                </div>
              </div>

              {/* Identification & Address Column */}
              <div className="col-md-6">
                <div className="glass-card p-4 h-100 rounded-3">
                  <h5 className="text-primary mb-4 border-bottom pb-2">
                    <i className="bi bi-house-fill me-2"></i>
                    Identification & Address
                  </h5>
                  
                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Register ID</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-card-text text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="registid"
                        value={formData.registid || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">PEN No</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-card-text text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="pen"
                        value={formData.pen || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">APAAR ID</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-card-text text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="apar"
                        value={formData.apar || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Saral ID</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-card-heading text-primary"></i>
                      </span>
                      <Form.Control
                        type="text"
                        name="sarlid"
                        value={formData.sarlid || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label className="fw-bold text-muted small">Address</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text bg-light">
                        <i className="bi bi-house-door text-primary"></i>
                      </span>
                      <Form.Control
                        as="textarea"
                        rows={3}
                        name="address"
                        value={formData.address || ''}
                        onChange={handleChange}
                        className="border-start-0"
                      />
                    </div>
                  </Form.Group>
                </div>
              </div>
            </div>

            <div className="d-flex justify-content-between mt-5">
              <Button 
                variant="outline-secondary" 
                onClick={onCancel}
                className="rounded-pill px-4 py-2 fw-bold"
              >
                <i className="bi bi-x-circle me-2"></i>
                Cancel
              </Button>
              
              <Button 
                variant="primary" 
                type="submit"
                className="rounded-pill px-4 py-2 fw-bold shadow"
              >
                <i className="bi bi-save-fill me-2"></i>
                Save Changes
              </Button>
            </div>
          </Form>
        </Card.Body>
      </Card>
    </Container>
  );
}

// Main StudentTable Component
function StudentTable() {
  const { state } = useLocation();
  const [students, setStudents] = useState([]);
  const [uploadedStudents, setUploadedStudents] = useState([]);
  const [editingStudent, setEditingStudent] = useState(null);
  const [showAllData, setShowAllData] = useState(false);
  const [showUploadPreview, setShowUploadPreview] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [uniqueClasses, setUniqueClasses] = useState([]);
  const Udise = state?.udiseNo;

  const [selectedClass, setSelectedClass] = useState(state?.classLevel);
  const [selectedDiv, setSelectedDiv] = useState(state?.classDiv);
  const [selectedYear, setSelectedYear] = useState(state?.academicYear);

  // Fetch students when showAllData becomes true
  useEffect(() => {
    if (!showAllData) return;

    const db = getDatabase();
    const studentsRef = ref(db, `Scinfo/${Udise}/ShareStudent`);

    const unsubscribe = onValue(studentsRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const allStudents = [];
          const classesSet = new Set(); 
        Object.keys(data).forEach(classKey => {
          const classStudents = data[classKey];
          Object.keys(classStudents).forEach(studentKey => {
            allStudents.push({
              id: studentKey,
              ...classStudents[studentKey],
              classKey: classKey
            });
            classesSet.add(classStudents[studentKey].classLevel);
          });
        });
        setStudents(allStudents);
        setUniqueClasses(Array.from(classesSet));
      } else {
        setStudents([]);
      }
    });

    return () => unsubscribe();
  }, [Udise, showAllData]);

  const handleViewData = () => {
    setShowAllData(true);
  };

  const handleDelete = (id, classKey) => {
    if (window.confirm("Are you sure you want to delete this student?")) {
      const db = getDatabase();
      const studentRef = ref(db, `Scinfo/${Udise}/ShareStudent/${classKey}/${id}`);
      remove(studentRef)
        .then(() => {
          alert("Student deleted successfully!");
        })
        .catch((error) => {
          console.error("Error deleting student:", error);
        });
    }
  };

  const handleEdit = (student) => {
    setEditingStudent(student);
  };

const handleSaveEdit = async (updatedData) => {
  try {
    // Convert DOB to the desired format before saving
    if (updatedData.DOB) {
      updatedData.DOB = format(new Date(updatedData.DOB), 'dd/MM/yyyy');
    }

    const db = getDatabase();
    const studentRef = ref(db, `Scinfo/${Udise}/ShareStudent/${updatedData.classKey}/${updatedData.id}`);
    
    await update(studentRef, updatedData);
    
    setStudents(prevStudents => 
      prevStudents.map(student => 
        student.id === updatedData.id ? updatedData : student
      )
    );
    
    setEditingStudent(null);
    alert('Student information updated successfully!');
  } catch (error) {
    console.error('Error updating student:', error);
    alert('Failed to update student information.');
  }
};



const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
  
    const reader = new FileReader();
    reader.onload = (event) => {
      const binaryData = event.target.result;
      const workbook = XLSX.read(binaryData, { type: "binary" });
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      let jsonData = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
  
      const formattedStudents = jsonData.map(student => ({
        id: student["ID"] || "", 
        classLevel: student["Class"] || "",
        classDiv: student["Division"] || "",
        academicYear: student["Year"] || "",
        Gender: student["Gender"] || "",
        sname: student["Student Name"] || "",
        adhar: student["Aadhaar"] || "",
        age: student["Age"] || "",
        DOB: formatExcelDate(student["DOB"]),
        mtlange: student["Mother Tongue Language"] || "",
        mobile: student["Mobile"] || "",
        registid: student["Register ID"] || "",
        pen: student["PEN No"] || "",
        apar: student["APAAR ID"] || "",
        rollno: student["Roll No"] || "",
        sarlid: student["Saral ID"] || "",
        address: student["Address"] || "",
        motherName: student["Mother Name"] || "",
        fatherName: student["Father Name"] || "",
        religion: student["Religion"] || "",
        caste: student["Caste"] || "",
        casteCategory: student["Caste Category"] || "",
        FMname: `${student["Father Name"] || ""}&&${student["Mother Name"] || ""}`,
        subcaste: `${student["Religion"] || ""}&&${student["Caste"] || ""}&&${student["Caste Category"] || ""}`,
        classdiv: `${student["Class"] || ""}&&${student["Division"] || ""}&&${student["Year"] || ""}`,
      }));
  
      setUploadedStudents(formattedStudents);
      setShowUploadPreview(true);
    };
  
    reader.readAsBinaryString(file);
  };

  
const formatExcelDate = (dob) => {
  if (!dob || dob === "") return "";

  // Try to parse the date using different formats
  let parsedDate;
  const formats = [
    'dd/MM/yyyy', // 15/08/2015
    'd/M/yyyy',   // 15/8/2015
    'MM/dd/yyyy', // 08/15/2015
    'yyyy-MM-dd', // 2015-08-15
    'dd-MM-yyyy', // 15-08-2015
    'd-M-yyyy',   // 15-8-2015
    'M/d/yyyy',   // 8/15/2015
    'yyyy/MM/dd', // 2015/08/15
    'dd.MM.yyyy', // 15.08.2015
    'd.M.yyyy',   // 15.8.2015
    // Add more formats as needed
  ];

  for (const fmt of formats) {
    try {
      parsedDate = parse(dob, fmt, new Date());
      if (!isNaN(parsedDate)) break; // Successfully parsed
    } catch (error) {
      // Continue to the next format
    }
  }

  // If parsedDate is valid, format it to the desired output
  if (parsedDate && !isNaN(parsedDate.getTime())) {
    return format(parsedDate, 'dd/MM/yyyy'); // Convert to desired format
  }

  return ""; // Return empty if parsing fails
};



const saveToFirebase = async () => {
  if (uploadedStudents.length === 0) {
    alert("No uploaded data to save!");
    return;
  }

  setIsSaving(true);
  const db = getDatabase();
  
  try {
    // 1. Get ALL existing student data
    const allExistingData = await new Promise((resolve) => {
      const studentsRef = ref(db, `Scinfo/${Udise}/ShareStudent`);
      onValue(studentsRef, (snapshot) => {
        resolve(snapshot.val() || {});
      }, { onlyOnce: true });
    });

    // 2. Prepare updates while preserving existing data
    const updates = {};
    let newStudentsCount = 0;
    let duplicateStudentsCount = 0;
    let updatedStudentsCount = 0;

    uploadedStudents.forEach((student) => {
      const classKey = student.classdiv || "defaultClass&&defaultDivision&&defaultYear";
      
      // Initialize class structure in updates if it doesn't exist
      if (!updates[classKey]) {
        // Start with existing data if available, otherwise empty object
        updates[classKey] = allExistingData[classKey] || {};
      }

      // Check if student exists in existing data
      const existingStudent = allExistingData[classKey]?.[student.id];
      
      if (!existingStudent) {
        // New student - add to updates
        updates[classKey][student.id] = {
          ...student,
          FMname: `${student.fatherName}&&${student.motherName}`,
          classdiv: classKey,
          subcaste: `${student.religion}&&${student.caste}&&${student.casteCategory}`
        };
        newStudentsCount++;
      } else {
        duplicateStudentsCount++;
        
     
      }
    });

    // 3. Only update paths that have changes (more efficient than writing everything)
    const rootRef = ref(db, `Scinfo/${Udise}/ShareStudent`);
    
    if (Object.keys(updates).length > 0) {
      await update(rootRef, updates);
    }

    // 4. Show results
    let message = `✅ Added ${newStudentsCount} new student(s).`;
    if (updatedStudentsCount > 0) {
      message += `\n🔄 Updated ${updatedStudentsCount} existing student(s).`;
    }
    if (duplicateStudentsCount > 0) {
      message += `\n❌ Skipped ${duplicateStudentsCount} duplicate(s).`;
    }
    alert(message);

    // 5. Reset UI
    setUploadedStudents([]);
    setShowUploadPreview(false);
    setShowAllData(false);
    setTimeout(() => setShowAllData(true), 100);
    
  } catch (error) {
    console.error("Error saving data:", error);
    alert("❌ Failed to save data. Please try again.");
  } finally {
    setIsSaving(false);
  }
};

// Helper function to refresh displayed data
const refreshData = () => {
  setShowAllData(false);
  setTimeout(() => setShowAllData(true), 100);
};

 const downloadExcel = () => {
    if (students.length === 0) {
      alert("No data available to download");
      return;
    }
  
    const formattedStudents = students.map(student => ({
      "ID": student.id || "",
      "Class": student.classLevel || "",
      "Division": student.classDiv || "",
      "Year": student.academicYear || "",
      "Gender": student.Gender || "",
      "Student Name": student.sname || "",
      "Aadhaar": student.adhar || "",
      "Age": student.age || "",
      "DOB": student.DOB || "",
      "Mother Tongue Language": student.mtlange || "",
      "Mobile": student.mobile || "",
      "Register ID": student.registid || "",
      "PEN No": student.pen || "",
      "APAAR ID": student.apar || "",
      "Roll No": student.rollno || "",
      "Saral ID": student.sarlid || "",
      "Address": student.address || "",
      "Mother Name": student.motherName || "",
      "Father Name": student.fatherName || "",
      "Religion": student.religion || "",
      "Caste": student.caste || "",
      "Caste Category": student.casteCategory || ""
    }));
  
    const worksheet = XLSX.utils.json_to_sheet(formattedStudents);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Students");
    XLSX.writeFile(workbook, `students_all_classes.xlsx`);
  };


  const handleDownload = () => {
    const storage = getStorage();
    const fileRef = storageRef(storage, 'gs://apollo11-90f5d.appspot.com/ExeclSheetTemplate/Student_Data.xlsx');
  
    getDownloadURL(fileRef)
      .then((url) => {
        const link = document.createElement("a");
        link.href = url;
        link.download = "Student_Data.xlsx";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      })
      .catch((error) => {
        console.error("Error downloading file:", error);
        alert("Failed to download file. Please try again.");
      });
  };

  const deleteall = () =>{
    if (window.confirm("Are you sure you want to delete all student?")) {
      const db = getDatabase();
      const studentRef = ref(db, `Scinfo/${Udise}/ShareStudent`);
      remove(studentRef)
        .then(() => {
          alert("All Student deleted successfully!");
        })
        .catch((error) => {
          console.error("Error deleting student:", error);
        });
    }
  }

  // Options for dropdowns
  const academicYears = [];
  const toMarathiNumerals = (num) => {
    const marathiDigits = ["०", "१", "२", "३", "४", "५", "६", "७", "८", "९"];
    return num
      .toString()
      .split("")
      .map((digit) => marathiDigits[parseInt(digit)])
      .join("");
  };

  for (let year = 2020; year < 2030; year++) {
    const startYear = toMarathiNumerals(year);
    const endYear = toMarathiNumerals((year + 1) % 100);
    academicYears.push(`${startYear}-${endYear}`);
  }

  // Define change handlers
  const handleClassChange = (e) => {
    setSelectedClass(e.target.value);
  };
  const handleDivChange = (e) => {
    setSelectedDiv(e.target.value);
  };
  const handleYearChange = (e) => {
    setSelectedYear(e.target.value);
  };

  const filteredStudents = students.filter(student => {
  return (
    (!selectedClass || student.classLevel === selectedClass) &&
    (!selectedDiv || student.classDiv === selectedDiv) &&
    (!selectedYear || student.academicYear === selectedYear)
  );
});


  return (
    <div className="container-fluid px-4 py-4" style={{ background: '#f8f9fa' }}>
      <div className="card shadow border-0 mb-4">
        <div className="card-header bg-primary text-white py-3">
          <button
            className="btn btn-danger btn-sm float-end me-2 "
            onClick={() => window.history.back()}
          >
            <i className="fas fa-arrow-left me-2"></i> Back
            </button>
          <h4 className="mb-0">
            <i className="fas fa-users me-2"></i> Student Management Dashboard
          </h4>
        </div>
        <div className="card-body">
          {!showAllData ? (
  <Card className="shadow-sm rounded-3 border-0 p-4 text-center">
    <h2 className="mb-4 fw-bold text-secondary">Student's Data</h2>
    <div className="d-flex justify-content-center gap-4">
      <Button 
        variant="primary" 
        size="lg"
        onClick={handleViewData}
        className="px-5 rounded-pill fw-semibold shadow-sm"
      >
        <i className="fas fa-database me-2"></i> View All Data
      </Button>
      <Button 
        variant="success" 
        size="lg"
        className="px-5 rounded-pill fw-semibold shadow-sm"
        onClick={() => setShowUploadModal(true)}
      >
        <i className="fas fa-file-upload me-2"></i> Import
      </Button>
    </div>
  </Card>
) : (

   <Card className="shadow-sm rounded-3 border-0 p-4 text-center">
    <h2 className="mb-4 fw-bold text-secondary">Student's Data</h2>
    <div className="d-flex justify-content-center gap-4">
      <Button 
        variant="primary" 
        size="lg"
        onClick={downloadExcel}
        className="px-5 rounded-pill fw-semibold shadow-sm"
      >
        <i className="fas fa-database me-2"></i> Export Data
      </Button>
      <Button 
        variant="success" 
        size="lg"
        className="px-5 rounded-pill fw-semibold shadow-sm"
        onClick={() => setShowUploadModal(true)}
      >
        <i className="fas fa-file-upload me-2"></i> Import
      </Button>
    </div>
  </Card>


          )}
        </div>
      </div>
<Modal
  show={showUploadModal}
  onHide={() => setShowUploadModal(false)}
  centered
  backdrop="static"
  keyboard={false}
  aria-labelledby="upload-modal-title"
>
  <Modal.Header closeButton>
    <Modal.Title id="upload-modal-title">Upload Excel File</Modal.Title>
  </Modal.Header>
  <Modal.Body className="d-flex flex-column align-items-center gap-3">
    <Button 
      variant="outline-primary" 
      onClick={handleDownload}
      className="w-100"
    >
      <i className="fas fa-file-download me-2"></i> Download Template
    </Button>
    <Form.Group className="mb-0 w-100">
      <Form.Label 
        htmlFor="modalFileUpload" 
        className="btn btn-success w-100 mb-0 rounded-pill fw-semibold"
        style={{ cursor: 'pointer' }}
      >
        <i className="fas fa-file-upload me-2"></i> Choose Excel File 
      </Form.Label>
      <Form.Control
        type="file"
        id="modalFileUpload"
        accept=".xlsx, .xls"
        onChange={handleFileUpload}
        hidden
      />
    </Form.Group>
  </Modal.Body>
</Modal>

      {editingStudent && (
        <EditStudentForm 
          studentData={editingStudent}
          udiseNo={Udise}
          selectedClass={editingStudent.classKey}
          onSave={handleSaveEdit}
          onCancel={() => setEditingStudent(null)}
        />
      )}

      {showUploadPreview && (
        <div className="card shadow border-warning mb-4">
          <div className="card-header  text-white py-3" style={{backgroundColor:'#5f95d9'}}>
            <h5 className="mb-3">
              <i className="fas fa-eye me-2 "></i> Upload Preview (Not Saved Yet)
            </h5>
            <div>
              <Button 
                variant="light" 
                size="sm" 
                onClick={() => {
                  setUploadedStudents([]);
                  setShowUploadPreview(false);
                }}
                className="me-2"
              >
                <i className="fas fa-times me-1"></i> Cancel
              </Button>
              <Button 
                variant="success" 
                size="sm"
                onClick={saveToFirebase}
                disabled={isSaving}
              >
                {isSaving ? (
                  <>
                    <span className="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>
                    Saving...
                  </>
                ) : (
                  <>
                    <i className="fas fa-save me-1"></i> Save to Database
                  </>
                )}
              </Button>
            </div>

           
          </div>
          <style jsx>
            {
              `
                th, td{
                  border: 1px solid gray;
                }
              `
            }
          </style>
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="table table-hover align-middle mb-0">
                <thead className="table-warning">
                 <tr>
                <th className="text-center">ID</th>
                <th>Class</th>
                <th>Division</th>
                <th>Year</th>
                <th>Gender</th>
                <th>Student Name</th>
                <th>Aadhaar</th>
                <th>DOB</th>
                <th>Age</th>
                <th>Mother Tongue</th>
                <th>Mobile</th>
                <th>Register ID</th>
                <th>PEN No</th>
                <th>APAAR ID</th>
                <th>Roll No</th>
                <th>Saral ID</th>
                <th>Address</th>
                <th>Mother Name</th>
                <th>Father Name</th>
                <th>Religion</th>
                <th>Caste</th>
                <th>Caste Category</th>
                {/* <th className="text-center">Actions</th> */}
              </tr>
                </thead>
                <tbody>
                  {uploadedStudents.map((student) => (
                    <tr key={student.id}>
                    <td className="text-center">{student.id}</td>
                    <td>{student.classLevel}</td>
                    <td>{student.classDiv}</td>
                    <td>{student.academicYear}</td>
                    <td>{student.Gender}</td>
                    <td className="fw-bold">{student.sname}</td>
                    <td>{student.adhar}</td>
                    <td>{student.DOB}</td>
                    <td>{student.age}</td>
                    <td>{student.mtlange}</td>
                    <td>{student.mobile}</td>
                    <td>{student.registid}</td>
                    <td>{student.pen}</td>
                    <td>{student.apar}</td>
                    <td>{student.rollno}</td>
                    <td>{student.sarlid}</td>
                    <td>{student.address}</td>
                    <td>{student.motherName}</td>
                    <td>{student.fatherName}</td>
                    <td>{student.religion}</td>
                    <td>{student.caste}</td>
                    <td>{student.casteCategory}</td>
                      {/* <td>
                        <button 
                          className="btn btn-sm btn-outline-danger"
                          onClick={() => {
                            setUploadedStudents(prev => 
                              prev.filter(s => s.id !== student.id)
                            );
                          }}
                        >
                          <i className="fas fa-times"></i> Remove
                        </button>
                      </td> */}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}


 {showAllData && (
        <div className="mb-3">
          <Row className="g-3">
            <Col xs={12} md={4}>
              <Form.Select value={selectedClass} onChange={handleClassChange}>
                <option value="">Select Class</option>
                {classLevelsOptions.map((option, index) => (
                  <option key={index} value={option.value}>{option.label}</option>
                ))}
              </Form.Select>
            </Col>
            <Col xs={12} md={4}>
              <Form.Select value={selectedDiv} onChange={handleDivChange}>
                <option value="">Select Division</option>
                {classDivOptions.map((option, index) => (
                  <option key={index} value={option.value}>{option.label}</option>
                ))}
              </Form.Select>
            </Col>
            <Col xs={12} md={4}>
              <Form.Select value={selectedYear} onChange={handleYearChange}>
                <option value="">Select Academic Year</option>
                {academicYears.map((year, index) => (
                  <option key={index} value={year}>{year}</option>
                ))}
              </Form.Select>
            </Col>
          </Row>
        </div>
      )}

      {showAllData && (
      
   <div className="card shadow-sm border-0 rounded-4 overflow-hidden">
  <div className="card-header bg-primary text-white py-3 px-4 d-flex justify-content-between align-items-center">
    <h5 className="mb-0 d-flex align-items-center">
      <i className="fas fa-user-graduate me-2"></i> Student Records
    </h5>
   
     <Button 
      variant="danger" 
      size="sm"
      className="rounded-pill fw-semibold"
      onClick={deleteall}
    >
      <i className="fas fa-sync-alt me-1"></i> Delete All
    </Button>
  </div>

  <div className="card-body p-0">
    <div className="table-responsive">
      <table className="table table-bordered align-middle mb-0" style={{ minWidth: '1500px' }}>
        <thead className="bg-light">
          <tr className="text-secondary text-uppercase small">
            <th className="text-center ps-4 border-end" style={{ width: '60px', backgroundColor:'gray' }}>ID</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Class</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Division</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Year</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Gender</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Student</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Aadhaar</th>
            <th style={{backgroundColor:'gray'}} className="border-end">DOB</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Age</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Language</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Mobile</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Reg ID</th>
            <th style={{backgroundColor:'gray'}} className="border-end">PEN No</th>
            <th style={{backgroundColor:'gray'}} className="border-end">APAAR ID</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Roll No</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Saral ID</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Address</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Mother</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Father</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Religion</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Caste</th>
            <th style={{backgroundColor:'gray'}} className="border-end">Category</th>
            <th style={{ width: '200px', backgroundColor:'gray' }} className="text-center pe-4" >Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredStudents.length > 0 ? (
            filteredStudents.map((student) => (
              <tr key={student.id} className="border-top">
                <td className="text-center ps-4 text-muted border-end">{student.id}</td>
                <td className="border-end">
                  <span className="badge bg-info-subtle text-dark rounded-pill px-3">
                    {student.classLevel}
                  </span>
                </td>
                <td className="border-end">
                  <span className="badge bg-light text-dark rounded-pill">
                    {student.classDiv}
                  </span>
                </td>
                <td className="border-end">{student.academicYear}</td>
                <td className="border-end">
                  <span className={`badge rounded-pill px-3 ${student.Gender === 'Male' ? 'bg-primary-subtle text-primary' : 'bg-danger-subtle text-danger'}`}>
                    {student.Gender}
                  </span>
                </td>
                <td className="fw-semibold text-primary border-end">{student.sname}</td>
                <td className="font-monospace border-end">{student.adhar}</td>
                <td className="border-end">{student.DOB}</td>
                <td className="text-center border-end">{student.age}</td>
                <td className="border-end">{student.mtlange}</td>
                <td className="font-monospace border-end">{student.mobile}</td>
                <td className="border-end">{student.registid}</td>
                <td className="border-end">{student.pen}</td>
                <td className="border-end">{student.apar}</td>
                <td className="text-center border-end">{student.rollno}</td>
                <td className="font-monospace border-end">{student.sarlid}</td>
                <td 
                  className="text-truncate border-end" 
                  style={{ maxWidth: '150px' }}
                  title={student.address}
                >
                  {student.address}
                </td>
                <td className="border-end">{student.motherName}</td>
                <td className="border-end">{student.fatherName}</td>
                <td className="border-end">{student.religion}</td>
                <td className="border-end">{student.caste}</td>
                <td className="border-end">
                  <span className="badge bg-light text-dark rounded-pill">
                    {student.casteCategory}
                  </span>
                </td>
                <td className="pe-4">
                  <div className="d-flex gap-2 justify-content-center">
                    <button 
                      className="btn btn-outline-primary btn-sm rounded-pill px-3"
                      onClick={() => handleEdit(student)}
                    >
                      <i className="fas fa-pen me-1"></i> Edit
                    </button>
                    <button 
                      className="btn btn-outline-danger btn-sm rounded-pill px-3"
                      onClick={() => handleDelete(student.id, student.classKey)}
                    >
                      <i className="fas fa-trash me-1"></i> Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="21" className="text-center py-4">
                <div className="d-flex flex-column align-items-center">
                  <i className="fas fa-user-slash text-muted mb-2" style={{ fontSize: '2rem' }}></i>
                  <span className="text-muted">No student records found</span>
                  <Button variant="outline-primary" size="sm" className="mt-2">
                    Add New Student
                  </Button>
                </div>
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  </div>
</div>
      )}
    </div>
  );
}



export default StudentTable;